package com.fiserv.dps.mobile.zelleplugin;

import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * This class echoes a string called from JavaScript.
 */
public class ZellePlugin extends CordovaPlugin {

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        Context context = cordova.getActivity().getApplicationContext();
                if(action.equals("zelle_activity")) {
                    String  message;
                    String duration;
                    try {
                        JSONObject options = args.getJSONObject(0);
                        Intent intent = new Intent(context, ZelleActivity.class);
                        intent.putExtra("ZelleObject", options.toString());
                        this.cordova.getActivity().startActivity(intent);
                    } catch (JSONException e) {
                        callbackContext.error("Error encountered: " + e.getMessage());
                        return false;
                    }
                    return true;
                }
                return false;
    }

    private void coolMethod(String message, CallbackContext callbackContext) {
        if (message != null && message.length() > 0) {
            callbackContext.success(message);
        } else {
            callbackContext.error("Expected one non-empty string argument.");
        }
    }
}
