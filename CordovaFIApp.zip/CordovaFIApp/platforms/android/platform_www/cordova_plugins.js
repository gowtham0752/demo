cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "com.fiserv.dps.mobile.zelleplugin.ZellePlugin",
      "file": "plugins/com.fiserv.dps.mobile.zelleplugin/www/ZellePlugin.js",
      "pluginId": "com.fiserv.dps.mobile.zelleplugin",
      "clobbers": [
        "ZellePlugin"
      ]
    }
  ];
  module.exports.metadata = {
    "com.fiserv.dps.mobile.zelleplugin": "1.0.0",
    "cordova-plugin-whitelist": "1.3.5"
  };
});