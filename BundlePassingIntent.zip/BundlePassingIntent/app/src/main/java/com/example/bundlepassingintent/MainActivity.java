package com.example.bundlepassingintent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    //initializing variables
    String TAG = "MainActivity";
    TextView heading;
    EditText name;
    EditText mobile;
    EditText password;
    Button Click;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG, "---------->onCreate");
        //initializing id
        name = (EditText) findViewById(R.id.name);
        mobile = (EditText) findViewById(R.id.mobile);
        password = (EditText) findViewById(R.id.password);
        Click = (Button) findViewById(R.id.button);

        //button initialization
        Click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name1 = name.getText().toString();
                String mobile1 = mobile.getText().toString();
                String password1 = password.getText().toString();

                Bundle mBundle = new Bundle();
                mBundle.putString("NAME", name1);
                mBundle.putString("MOBILE", mobile1);
                mBundle.putString("PASSWORD", password1);


                Intent i = new Intent (MainActivity.this,SecondActivity.class);
                i.putExtras(mBundle);
                startActivity(i);

            }
        });    }
}
