package com.example.bundlepassingintent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    // Variable declaration
    String TAG = SecondActivity.class.getSimpleName();
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set layout for this activity
        setContentView(R.layout.activity_second);

        Log.d(TAG, "-------------> onCreate");

        result = (TextView) findViewById(R.id.result);


        String name = getIntent().getExtras().getString("NAME");
        String mobile = getIntent().getExtras().getString("MOBILE");
        String password = getIntent().getExtras().getString("PASSWORD");

        result.setText("Name: " + name  + "\nMobile: " + mobile + "\nPassword: " +password);



    }
}
