package com.fiserv.dps.mobile.sdk

import com.fiserv.dps.mobile.sdk.utils.Validator.validateBitmap
import junit.framework.TestCase.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class TestPhoto {
    @Test
    fun testCaseOne(){ //checking null or not
        val bitmap = null
        assertEquals(validateBitmap(bitmap), true)
    }
}