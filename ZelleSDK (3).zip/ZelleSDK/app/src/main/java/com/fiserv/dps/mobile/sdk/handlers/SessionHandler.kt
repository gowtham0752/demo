package com.fiserv.dps.mobile.sdk.handlers

import android.webkit.JavascriptInterface
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.utils.Constants
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.SESSION_TIME_OUT_MESSAGE
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil

/**
 * SessionHandler created to handle app session.
 * This interface will be called from java script.
 * FTKTimeOut() function used to show alert dialog to the user.
 * Created by F5SP0MG on 21,June,2021
 */
interface SessionHandler {
    @JavascriptInterface fun sessionTimeout()
}
/**
 * SessionHandler class has been implemented here to perform their actions
 * Created by F5ZF5DH on 25,July,2021
 */
class SessionHandlerImpl(private val fragment: BridgeFragment): SessionHandler {
    @JavascriptInterface
    override fun sessionTimeout() {
        fragment.requireActivity().supportFragmentManager.beginTransaction().remove(fragment).commit()
//        PermissionUtil.alertDialogue(
//            fragment = fragment,
//            title = "Session Time Out",
//            message = SESSION_TIME_OUT_MESSAGE,
//            positiveButton = "Yes",
//            negativeButton = "No",
//            code = Constants.SESSION_TIMEOUT)
    }
}