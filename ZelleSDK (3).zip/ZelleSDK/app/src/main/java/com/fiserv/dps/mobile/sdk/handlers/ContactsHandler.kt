package com.fiserv.dps.mobile.sdk.handlers

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.webkit.JavascriptInterface
import androidx.activity.result.contract.ActivityResultContracts
import com.fiserv.dps.mobile.sdk.activity.ContactDetailActivity
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.utils.*
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CACHING_TIME
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_ALL_CONTACT_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_CONTACT_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_CONTACT
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.VALID_USER_NAME
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil.callbackPermission
import org.json.JSONArray
import org.json.JSONObject

/**
 * ContactsHandler created to access contact and get single and all contact from native contact application
 * this interface will be called from java script
 * getContacts() function will be handle to get all contacts from native contact application
 * getOneContact() function will handle to get selected from native contact application
 * Created by F5SP0MG on 16,June,2021
 */
interface ContactsHandler {
    @JavascriptInterface fun getContacts()
    @JavascriptInterface fun getOneContact()
}

/**
 * ContactsHandler class has been implemented to get the contacts from native OS
 */
class ContactsHandlerImpl(
    private val fragment: BridgeFragment,
    private val evaluateJS: (String) -> Unit
) : ContactsHandler {

    private val jsonObject = JSONObject()

    /**
     * This method check contact read permission and open  intent to native contact page
     * Created by F6W0W4F  on 23,June,2021
     */
    private val contactActivityResultLauncher =
        fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            /**
             * Pass single contact data to ContactDetailActivity
             */
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val uriContact = result.data!!.data
                val intent = Intent(fragment.requireContext(), ContactDetailActivity::class.java)
                intent.data = uriContact
                detailedContactActivityResultLauncher.launch(intent)
            }
        }

    /**
     * This method get single contact and pass data to javascript function callbackOneContact
     * Created by F6W0W4F on 09,July,2021
     */
    private val detailedContactActivityResultLauncher =
        fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val contact = JSONObject(result.data?.getStringExtra(Constants.CONTACT_DETAILS)!!)
                if (contact.has("name") && (contact.has("email") || contact.has("phone"))) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        evaluateJS("callbackOneContact({contact: '${contact}'})")
                    }, 1000)
                } else {
                    /**
                     * Invalid contact alert
                     */
                    PermissionUtil.alertDialogue(
                        fragment = fragment,
                        message = Constants.INVALID_CONTACT_DETAIL,
                        code = VALID_USER_NAME
                    )
                }
            }
            /**
             * Contact read permission check
             */
            if (result.resultCode == Activity.RESULT_CANCELED) {
                if (PermissionUtil.checkPermissionForReadContact(fragment.requireContext())) {
                    getSingleContact()
                }
            }
        }

    /**
     * Check threshold limit  for single contact
     * Custom alertDialogue will be initiated
     * Created by F6W0W4F  on 23,June,2021
     */
    private val singleContactActivityResultForPermission = fragment.registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it){
            fragment.setThreshold(THRESHOLD_LIMIT_CONTACT)
            getSingleContact()
        }else{
            PermissionUtil.checkUserRequestedDoNotAskAgainContact(fragment, REQUEST_READ_CONTACT_PERMISSION_SETTINGS, singleContactSettingsActivityResultLauncher)
        }
    }

    /**
     * Check threshold limit  for all contact
     * Custom alertDialogue will be initiated
     * Created by F5SP0MG on 01,July,2021
     */
    private val allContactActivityResultForPermission = fragment.registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it){
            fragment.setThreshold(THRESHOLD_LIMIT_CONTACT)
            jsonObject.put("user_action", "allowed")
            callContactsThread()
            callbackPermission(fragment , evaluateJS)
        }else{
            val jo = JSONObject()
            jo.put("cached", false)
            jo.put("user_action", "denied")
            callbackContacts(jo)
            callbackPermission(fragment , evaluateJS)
            PermissionUtil.checkUserRequestedDoNotAskAgainContact(fragment, REQUEST_READ_ALL_CONTACT_PERMISSION_SETTINGS, allContactSettingsActivityResultLauncher)
        }
    }

    /**
     * This singleContactSettingsActivityResultLauncher used to check permission and call single contact function
     * Created by F6W0W4F  on 23,June,2021
     */
    private val singleContactSettingsActivityResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (PermissionUtil.checkPermissionForReadContact(fragment.requireContext())){
             getSingleContact()
        }
    }

    /**
     * This allContactSettingsActivityResultLauncher used to check permission and call all contact function
     * Created by F5SP0MG on 01,July,2021
     */
    private val allContactSettingsActivityResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (PermissionUtil.checkPermissionForReadContact(fragment.requireContext())){
            jsonObject.put("user_action", "allowed")
            callContactsThread()
            callbackPermission(fragment , evaluateJS)
         }
        /*else{
            val jo = JSONObject()
            jo.put("cached", false)
            jo.put("user_action", "denied")
            callbackContacts(jo)
            callbackPermission(fragment , evaluateJS)
        }*/
    }

    /**
     * Javascript to  call getContacts  function get all contact from  native OS if last update exceeds 24hrs
     * Otherwise it will return cached true
     */
    @JavascriptInterface
    override fun getContacts() {
        val cache = ThresholdLimitPreference.getLimit(fragment.requireContext(), CACHING_TIME)

        if (PermissionUtil.checkPermissionForReadContact(fragment.requireContext())) {
            /**
             * Checking the time that stored in the preferences if it is empty or equal to zero then
             * it will call callbackContacts with getContactList else
             * it will return cache as true to WebView
             */
            if(cache.isNotEmpty()){
                val getExtraTime = TimePickerUtil.getExtraHourWithTimeGiven(24, cache)
                val time = TimePickerUtil.timeDifferenceInHour(getExtraTime, TimePickerUtil.getCurrentTime())
                if(time[0]!! <= 0 && time[1]!! <= 0){
                    callContactsThread()
                }else{
                    retriveCachedContacts()
                }
            }else{
                callContactsThread()
            }
        } else {
            allContactActivityResultForPermission.launch(android.Manifest.permission.READ_CONTACTS)
        }

    }

    /**
     * Javascript to  call getOneContact  function get single contact from native OS
     */
    @JavascriptInterface
    override fun getOneContact() {
        if (PermissionUtil.checkPermissionForReadContact(fragment.requireContext())) {
            getSingleContact()
        } else {
            singleContactActivityResultForPermission.launch(android.Manifest.permission.READ_CONTACTS)
        }
    }

    /**
     * callbackContacts will be return the status of fetching all contact,
     * to be stored in the WebView or not (i.e. cached =true/false) in the format of json object
     * Created by F5SP0MG on 23,June,2021
     */
    private fun callbackContacts(allContacts: JSONObject) {
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackContacts({contact: '${allContacts}'})")
        }, 1000)
    }

    /**
     * retriveCachedContacts will fetched all the cached contacts from sharedPreference,
     * Created by F6W0W4F on 13,December,2021
     */
    private fun retriveCachedContacts(){
        val cachedContacts = ThresholdLimitPreference.getLimit(fragment.requireContext() , Constants.CACHED_CONTACTS)
        val contactArray = JSONArray(cachedContacts)
        val js = "var cachedContacts = ${contactArray};"
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS(js)
        }, 1000)

        val jo = JSONObject()
        jo.put("cached", true)
        callbackContacts(jo)
    }

    /**
     * getSingleContact is used to initiate the native contact screen to get a particular contact
     * Created by F6W0W4F  on 23,June,2021
     */
    private fun getSingleContact() {
        val i = Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI)
        contactActivityResultLauncher.launch(i)
    }

    private fun callContactsThread(){
        val getContacts = ContactsThreadHandler(fragment, evaluateJS)
        Thread(getContacts).start()
    }

    /**
     * callbackPermission will be return the status of the permissions given by the user,
     * and it will shared to the WebView
     */

}