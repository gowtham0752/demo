package com.fiserv.dps.mobile.sdk.bridge.model

/**
 * Model calss for errors
 * Created by F5SP0MG on 18,June,2021
 */
data class ErrorObject(var id: String, var msg : String)