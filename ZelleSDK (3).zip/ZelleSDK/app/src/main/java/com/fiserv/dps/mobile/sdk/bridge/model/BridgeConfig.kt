package com.fiserv.dps.mobile.sdk.bridge.model

/**
 * It contains the configuration parameters
 * Created by F5SP0MG on 16,June,2021
 */
interface BridgeConfig {
    var appName: String
    var url: String
    var preCacheContacts: Boolean
}

class BaseConfig(override var appName: String, override var url: String): BridgeConfig {
    override var preCacheContacts = false
}