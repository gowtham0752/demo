package com.fiserv.dps.mobile.sdk.handlers

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.webkit.JavascriptInterface
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.fiserv.dps.mobile.sdk.activity.ScanQRActivity
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.utils.Constants
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_QR_CAMERA_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_QR_GALLERY_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_CAMERA
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_GALLERY
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil.callbackPermission
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import org.json.JSONObject
import java.io.File

/**
 * QRCodeHandler created to handle, get data from qr code.
 * This interface will be called from java script.
 * scanQRCode() function used to scan qr code using camera.
 * selectQRCodeFromPhotos() function used to read qr code from image picked from gallery/external storage.
 * Created by F5SP0MG on 21,June,2021
 */
interface QRCodeHandler {
    @JavascriptInterface fun scanQRCode()
    @JavascriptInterface fun selectQRCodeFromPhotos()
}

/**
 * QRCodeHandler class has been implemented here to perform their actions
 */
class QRCodeHandlerImpl(private val fragment: BridgeFragment, private val evaluateJS: (String) -> Unit): QRCodeHandler {

    private lateinit var imageUri: Uri

    /**
     * cameraActivityResultForPermission check  Threshold limit , intent pass to camera
     * Created by F6W0W4F on 02,July,2021
     */
    private val cameraActivityResultForPermission = fragment.registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it){
            fragment.setThreshold(THRESHOLD_LIMIT_CAMERA)
            openQR()
        }else{
            val jo = JSONObject()
            jo.put("user_action", "denied")
            jo.put("qr_value", "")
            callBackQR(jo)
            callbackPermission(fragment , evaluateJS )
            PermissionUtil.checkUserRequestedDoNotAskAgainCamera(fragment, REQUEST_READ_QR_CAMERA_PERMISSION_SETTINGS, cameraSettingsActivityResultLauncher)
        }
    }

    /**
     * Get result from  zxing and call the callBackQR method
     * Created by F6W0W4F on 02,July,2021
     */
   /* private val zxingActivityResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
        val result = IntentIntegrator.parseActivityResult(it.resultCode, it.data)

        if (result.contents != null){
            if (result.contents == null) {
                //PermissionUtil.alertDialogue(fragment = fragment, message = NO_DATA_FOUND, code = VALID_USER_NAME)
                val jo = JSONObject()
                jo.put("user_action", "allowed")
                jo.put("qr_value", "")
                Log.d("Scan Qr Result","-------------->${jo}")
                callBackQR(jo)
                callbackPermission(fragment , evaluateJS )
            } else {
                val jo = JSONObject()
                jo.put("user_action", "allowed")
                jo.put("qr_value", result.contents)
                Log.d("Scan Qr Result","-------------->${jo}")
                callBackQR(jo)
                callbackPermission(fragment , evaluateJS )
            }
        }else{
            val jo = JSONObject()
            jo.put("user_action", "allowed")
            jo.put("qr_value", "")
            Log.d("Scan Qr Result","-------------->${jo}")
            callBackQR(jo)
            callbackPermission(fragment , evaluateJS )
        }
    }
*/
    /**
     * Check permission for camera and openQR method call
     * Created by F6W0W4F on 02,July,2021
     */
    private val cameraSettingsActivityResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (PermissionUtil.checkPermissionForCamera(fragment.requireContext())){
            openQR()
        }else{
            val jo = JSONObject()
            jo.put("user_action", "denied")
            jo.put("qr_value", "")
            callBackQR(jo)
            callbackPermission(fragment , evaluateJS )
        }
    }

    /**
     * This photoActivityResultLauncher get gallery image uri and  encode image result
     * Created by F5OWV6C on 04,July,2021
     */
    private val photoActivityResultLauncher =
        fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                try {
                    @Suppress("DEPRECATION")
                    val bitmap = MediaStore.Images.Media.getBitmap(fragment.context?.contentResolver, result.data?.data)
                    val intArray = IntArray(bitmap.width * bitmap.height)
                    bitmap.getPixels(intArray, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
                    val luminanceSource = RGBLuminanceSource(bitmap.width, bitmap.height, intArray)
                    val binaryBitmap = BinaryBitmap(HybridBinarizer(luminanceSource))
                    val reader = MultiFormatReader()
                    val res = reader.decode(binaryBitmap)
                    val jo = JSONObject()
                    jo.put("user_action", "allowed")
                    jo.put("qr_value", res.text )
                    callBackQR(jo)
                    callbackPermission(fragment , evaluateJS )
                } catch (e: Exception) {
                    /**
                     * When qr code reader throws some exception, then will send empty qr_value
                     */
                    val jo = JSONObject()
                    jo.put("user_action", "allowed")
                    jo.put("qr_value", "")
                    callBackQR(jo)
                    callbackPermission(fragment , evaluateJS )
                   /* PermissionUtil.alertDialogue(
                        fragment = fragment,
                        message = INVALID_QR_CODE,
                        code = VALID_USER_NAME
                    )*/
                }
            }
            /*else {
                *//**
                 * When qr code reader not reading anything, will sent empty qr_value
                 *//*
                val jo = JSONObject()
                jo.put("user_action", "allowed")
                jo.put("qr_value", "")
                callBackQR(jo)
                callbackPermission(fragment , evaluateJS )
                *//*PermissionUtil.alertDialogue(
                    fragment = fragment,
                    message = NO_DATA_FOUND,
                    code = VALID_USER_NAME
                )*//*
            }*/
        }

    /**
     * Threshold limit check storage and intent pass to gallery
     * Created by F5OWV6C on 04,July,2021
     */
    private val storageActivityResultForPermission = fragment.registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it){
            fragment.setThreshold(THRESHOLD_LIMIT_GALLERY)
            openGallery()
        }else{
            val jo = JSONObject()
            jo.put("user_action", "denied")
            jo.put("qr_value", "")
            callBackQR(jo)
            callbackPermission(fragment , evaluateJS )
            PermissionUtil.checkUserRequestedDoNotAskAgainGallery(fragment, REQUEST_READ_QR_GALLERY_PERMISSION_SETTINGS, storageSettingsResultLauncher)
        }
    }

    /**
     * Check permission for gallery/external storage
     * OpenGallery function will call the intent to select image from gallery/external storage
     * Created by F5OWV6C on 04,July,2021
     */
    private val storageSettingsResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (PermissionUtil.checkPermissionForGallery(fragment.requireContext())){
            openGallery()
        }
    }

    /**
     * scanQRCode() function call to scan qr code using camera from native OS
     */
    @JavascriptInterface
    override fun scanQRCode() {
        if(PermissionUtil.checkPermissionForCamera(fragment.requireContext())){
            openQR()
        }else{
            cameraActivityResultForPermission.launch(Manifest.permission.CAMERA)
        }
    }

    /**
     * selectQRCodeFromPhotos() function used to read qr code image from gallery/external storage.
     */
    @JavascriptInterface override fun selectQRCodeFromPhotos() {
        fragment.getActivity()?.runOnUiThread {
            if(PermissionUtil.checkPermissionForGallery(fragment.requireContext())){
                openGallery()
            }else{
                storageActivityResultForPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
    }

    /**
     * openGallery function will initiate the intent to select qr code image from gallery/external storage
     * Created by F5OWV6C on 04,July,2021
     */
    private fun openGallery(){
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        val path = File(fragment.context?.getExternalFilesDir(null)?.absolutePath, "Pic.jpg")
        if(path.exists()){
            path.delete()
            path.createNewFile()
        }
        imageUri = FileProvider.getUriForFile(fragment.requireContext(), Constants.APPLICATION_ID + ".file_provider", path)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
        intent.type = "image/*"
        photoActivityResultLauncher.launch(intent)
    }

    /**
     * openQR function will initiate the Zxing library to scan the qr code
     * Created by F6W0W4F on 02,July,2021
     */
    private fun openQR(){
//        val integrator = IntentIntegrator.forSupportFragment(fragment)
//        integrator.setPrompt("Scan a barcode")
//        integrator.setCameraId(0) // Use a specific camera of the device
//        integrator.setBeepEnabled(false)
//        integrator.setOrientationLocked(true)
//        integrator.setTimeout(15000)
//        integrator.setBarcodeImageEnabled(true)
//        zxingActivityResultLauncher.launch(integrator.createScanIntent())
        val intent = Intent(fragment.requireActivity(), ScanQRActivity::class.java)
        qrScanActivityResultLauncher.launch(intent)
    }

    private val qrScanActivityResultLauncher =
        fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val scanResult = result.data?.getStringExtra(Constants.SCAN_RESULT)!!
                if (scanResult.isNotEmpty()){
                        val jo = JSONObject()
                        jo.put("user_action", "allowed")
                        jo.put("qr_value", scanResult)
                        Log.d("Scan Qr Result","-------------->${jo}")
                        callBackQR(jo)
                        callbackPermission(fragment , evaluateJS )
                }else{
                    val jo = JSONObject()
                    jo.put("user_action", "allowed")
                    jo.put("qr_value", "")
                    Log.d("Scan Qr Result","-------------->${jo}")
                    callBackQR(jo)
                    callbackPermission(fragment , evaluateJS )
                }
            }
        }

    /**
     * callBackQR will return scanned/selected qr code result to the WebView,
     * @param result
     * Created by F6W0W4F on 02,July,2021
     */
    private fun callBackQR(result: JSONObject) {
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackQRCode({code: '${result}'})")
        }, 1000)
    }
}