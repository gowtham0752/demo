package com.fiserv.dps.mobile.sdk.bridge.view

import android.app.Activity
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.bridge.model.BridgeConfig

/**
 * Will be shown to user as a view which will be integrated to the activity/fragment in the parent app
 * Created by F5SP0MG on 16,June,2021
 */
class BridgeView: BridgeFragment{
    constructor() : super()
    constructor(activity: Activity, config: BridgeConfig): super(activity, config, false)
}