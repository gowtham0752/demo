package com.fiserv.dps.mobile.sdk.utils

import android.content.Context
import androidx.annotation.Nullable

/**
 * ThresholdLimitPreference helps to store and get the details about the user permission
 * to the preferences for the function which is needed user permission for their task
 * Created by F5ZF5DH on 01,July,2021
 */
class ThresholdLimitPreference {

    companion object{

        /**
         * To save threshold limit to shared preferences
         * @param key
         * @param value
         * @param context
         */
        fun save(@Nullable key : String, @Nullable value : String, context: Context?) {
            if (value.isNotEmpty()) {
                AppComUtils.setPreferenceString(context!!, key, value)
            } else {
                AppComUtils.setPreferenceString(context!!, key, "false")
            }
        }

        /**
         * To get threshold limit to shared preferences
         * @param context
         * @param key
         * @return String
         */
        @Nullable
        fun getLimit(context: Context?,key: String): String {
            return AppComUtils.getPreferenceString(context!!, key)
        }
    }
}