package com.fiserv.dps.mobile.sdk.activity

import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import androidx.appcompat.app.AppCompatActivity
import com.fiserv.dps.mobile.sdk.adapter.ContactDetailsListAdapter
import com.fiserv.dps.mobile.sdk.R
import com.fiserv.dps.mobile.sdk.utils.CircleImage.circleBitmap
import com.fiserv.dps.mobile.sdk.utils.CircleImage.generateCircleBitmap
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CONTACT_DETAILS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.INVALID_CONTACT_NAME
import com.fiserv.dps.mobile.sdk.utils.ContactUtil
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil
import com.fiserv.dps.mobile.sdk.utils.Validator.validateName
import kotlinx.android.synthetic.main.activity_contact_detail.*
import org.json.JSONObject

/**
 * Custom view and functionalities for contact details page
 * Created by F6W0W4F on 09,July,2021
 */
class ContactDetailActivity : AppCompatActivity() {
    private lateinit var contactDetailsAdapter: ContactDetailsListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_detail)
        init()
        if (intent.data != null) {
            getContactData(intent.data!!)
        }
    }

    /**
     * This function perform  OnClickListener result send to previous page
     */
    private fun init() {
        back_press.setOnClickListener {
            sendResultBack(RESULT_CANCELED, "")
        }
    }

    /**
     * This function perform native back press result send to previous page
     */
    override fun onBackPressed() {
        super.onBackPressed()
        sendResultBack(RESULT_CANCELED, "")
    }

    /**
     * This function create recyclerview and load single contact details  using params
     * @param data : ArrayList<String>
     * @param name : String
     */
    private fun setRecyclerview(data: ArrayList<String>, name: String) {
        contactDetailsAdapter = ContactDetailsListAdapter(this, data, object :
            ContactDetailsListAdapter.ContactsClick {
            override fun getContact(value: String) {
                val jObject = JSONObject()
                val number: String?
                val email: String?
                jObject.put("name", name)
                if (value.startsWith("@")) {
                    number = value.drop(1)
                    jObject.put("phone", number)
                    jObject.put("tokenType", "phone")
                }else{
                    email = value
                    jObject.put("email", email)
                    jObject.put("tokenType", "email")
                }
//                if (validateMobileNumber(value)) {
//                    number = value.filter { it.isDigit() }
//                    jObject.put("phone", number)
//                    jObject.put("type", "phone")
//                } else if (validateEmail(value)) {
//                    email = value
//                    jObject.put("email", email)
//                    jObject.put("type", "email")
//                }
                if (validateName(name)) {
                    sendResultBack(RESULT_OK, jObject.toString())
                } else {
                    PermissionUtil.alertDialogue(
                        this@ContactDetailActivity,
                        "",
                        INVALID_CONTACT_NAME,
                        "OK"
                    )
                }
            }
        })
        rcv_contact_details.adapter = contactDetailsAdapter
    }

    /**
     * get contact details from contact uri
     * @param uriContact
     */
    private fun getContactData(uriContact: Uri) {
        val cursorID: Cursor = contentResolver.query(
            uriContact, arrayOf(ContactsContract.Contacts._ID),
            null, null, null
        )!!
        if (cursorID.moveToFirst()) {
            val contactID =
                cursorID.getString(cursorID.getColumnIndex(ContactsContract.Contacts._ID))
            val name = ContactUtil.getContactName(applicationContext, uriContact)
            val phoneArray = ContactUtil.getContactNumber(applicationContext, contactID, false)
            val emailArray = ContactUtil.getEmailDetails(applicationContext, contactID, false)
            val photoBitmap = ContactUtil.getContactPhoto(applicationContext, contactID)
            if (photoBitmap != null) {
                cv_contact_profile.setImageDrawable(circleBitmap(resources, photoBitmap))
            } else {
                cv_contact_profile.setImageDrawable(
                    circleBitmap(
                        resources, generateCircleBitmap(
                            70.0f, name.substring(0, 1)
                        )!!
                    )
                )
            }
            tv_contact_name.text = name
            val data = ArrayList<String>()
            data.addAll(phoneArray)
            data.addAll(emailArray)
            setRecyclerview(data, name)
        }
        cursorID.close()
    }

    /**
     * send the result back to the bridge fragment
     * @see com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
     */
    fun sendResultBack(result: Int, contact: String) {
        val returnIntent = Intent()
        if (contact.isNotEmpty()) {
            returnIntent.putExtra(CONTACT_DETAILS, contact)
        }
        setResult(result, returnIntent)
        finish()
    }
}