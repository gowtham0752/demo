package com.fiserv.dps.mobile.sdk.utils

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import com.fiserv.dps.mobile.sdk.utils.Validator.validateEmail
import com.fiserv.dps.mobile.sdk.utils.Validator.validateMobileNumber
import java.io.IOException
import java.io.InputStream

/**
 * ContactUtil contains the function to return name, email, phone and photo from contact uri
 * Created by F5SP0MG on 22,June,2021
 */
object ContactUtil {

    /**
     * getContactNumber() will return the list of phone numbers from contactID
     */
    fun getContactNumber(
        context: Context,
        contactID: String,
        validation: Boolean
    ): ArrayList<String> {
        val contactNumber = ArrayList<String>()
        val duplicateNumber = HashSet<String>()
        val cursorPhone: Cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", arrayOf(contactID),
            null
        )!!
        while (cursorPhone.moveToNext()) {
            val phone =
                cursorPhone.getString(cursorPhone.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
            if (validation) {
                if (validateMobileNumber(phone)) {
                    val number = phone.filter { it.isDigit() }
                    contactNumber.add(number)
                }
            } else {
                contactNumber.add("@$phone")
            }
        }
        cursorPhone.close()
        duplicateNumber.addAll(contactNumber)
        contactNumber.clear()
        contactNumber.addAll(duplicateNumber)
        return contactNumber
    }

    /**
     * getEmailDetails() will return list of emails from contactID
     */
    fun getEmailDetails(
        context: Context,
        contactID: String,
        validation: Boolean
    ): ArrayList<String> {
        val emailId = ArrayList<String>()
        val duplicateMail = HashSet<String>()
        val cursor: Cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
            ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?", arrayOf(contactID),
            null
        )!!
        while (cursor.moveToNext()) {
            val email =
                cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA))
            if (validation) {
                if (validateEmail(email)) {
                    emailId.add(email.lowercase())
                }
            } else {
                emailId.add(email.lowercase())
            }
        }
        cursor.close()
        duplicateMail.addAll(emailId)
        emailId.clear()
        emailId.addAll(duplicateMail)
        return emailId
    }

    /**
     * getContactPhoto() will return the photo from contactID
     */
    fun getContactPhoto(context: Context, contactID: String): Bitmap? {
        var photo: Bitmap? = null
        try {
            val inputStream: InputStream? = ContactsContract.Contacts.openContactPhotoInputStream(
                context.contentResolver,
                ContentUris.withAppendedId(
                    ContactsContract.Contacts.CONTENT_URI,
                    contactID.toLong()
                )
            )
            if (inputStream != null) {
                photo = BitmapFactory.decodeStream(inputStream)
            }
            if (inputStream != null) {
                return photo!!
                @Suppress("UNREACHABLE_CODE")
                inputStream.close()
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return null
    }

    /**
     * getContactName() will return the name from uriContact
     */
    fun getContactName(context: Context, uriContact: Uri): String {
        var contactName: String? = null
        // querying contact data store
        val cursor = context.contentResolver.query(uriContact, null, null, null, null)
        if (cursor!!.moveToFirst()) {
            // DISPLAY_NAME = The display name for the contact.
            // HAS_PHONE_NUMBER =   An indicator of whether this contact has at least one phone number.
            contactName =
                cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))
        }
        cursor.close()
        return contactName!!
    }
}
