package com.fiserv.dps.mobile.sdk.utils

import com.fiserv.dps.mobile.sdk.utils.Validator.validateContact
import org.json.JSONObject

/**
 *QrUtils helps to validate qr code
 * Created by F5OWV6C on 01,July,2021
 */
object QrUtils {
    /**
     * checkQrCode convert string to json object then it will validate the result and return the result
     * @param data -string
     *@return boolean value
     */
    fun checkQrCode(data: String): Boolean {
        try {
            val contacts = JSONObject(data)
            if (validateContact(contacts)) {
                return true
            }
        } catch (e: Exception) {
            return false
        }
        return false
    }
}