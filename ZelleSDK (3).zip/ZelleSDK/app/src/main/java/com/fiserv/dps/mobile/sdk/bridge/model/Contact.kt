package com.fiserv.dps.mobile.sdk.bridge.model
/**
 * model class for contact
 * Created by F5SP0MG on 18,June,2021
 */
data class Contact( var name: String? = null, var phone: String? = null, var email: String? = null)