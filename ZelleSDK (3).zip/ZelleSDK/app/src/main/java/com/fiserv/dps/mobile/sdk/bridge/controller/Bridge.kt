package com.fiserv.dps.mobile.sdk.bridge.controller

import android.app.Activity
import com.fiserv.dps.mobile.sdk.bridge.model.BridgeConfig
import com.fiserv.dps.mobile.sdk.bridge.view.BridgePopup
import com.fiserv.dps.mobile.sdk.bridge.view.BridgeView

/**
 * Bridge contains the views(BridgeView and BridgePopup)
 * Created by F5SP0MG on 16,June,2021
 */
class Bridge(
    private val activity: Activity,
    private var config: BridgeConfig
) {
    fun view() = BridgeView(activity, config)
    fun popup() = BridgePopup(activity, config)
}