package com.fiserv.dps.mobile.sdk.utils

import org.json.JSONException
import org.json.JSONObject

/**
 * JsonFormatterUtil helps to convert data from Gson to Json format
 * Created by F6W0W4F on 10/22/2021
 */
object JsonFormatterUtil {

    /**
     * toJson() - Convert Gson object to Json object
     */
    @kotlin.jvm.Throws(JSONException::class, IllegalAccessException::class)
    fun toJson(`object`: Any):JSONObject{
        val c:Class<*> = `object`.javaClass
        val jsonObject = JSONObject()
        for(field in c.declaredFields){
            field.isAccessible = true
            val  name = field.name
            val value = java.lang.String.valueOf(field[`object`])
            if (!value.equals("null"))
            jsonObject.put(name, value)
        }

        return jsonObject
    }
}