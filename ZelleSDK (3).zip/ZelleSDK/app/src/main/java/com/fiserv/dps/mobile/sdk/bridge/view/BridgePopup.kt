package com.fiserv.dps.mobile.sdk.bridge.view

import android.app.Activity
import android.view.Gravity
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.bridge.model.BridgeConfig

/**
 * Will be shown to user as a popup which will be integrated to the activity/fragment in the parent app
 * Created by F5SP0MG on 16,June,2021
 */
class BridgePopup: BridgeFragment {

    constructor() :super()
    constructor(activity: Activity , config: BridgeConfig) : super(activity, config, true)

   /* override fun onStart() {
        super.onStart()
        dialog?.window?.apply {
            resources.displayMetrics.also {
                setLayout(it.widthPixels, (it.heightPixels * 0.8).toInt())
                setGravity(Gravity.BOTTOM)
            }
        }
        isCancelable = false
    }*/
}