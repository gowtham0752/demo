package com.fiserv.dps.mobile.sdk.bridge.controller


import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.*
import android.view.View.GONE
import android.view.View.VISIBLE
import android.webkit.*
import androidx.fragment.app.DialogFragment
import com.fiserv.dps.mobile.sdk.R
import com.fiserv.dps.mobile.sdk.bridge.model.BridgeConfig
import com.fiserv.dps.mobile.sdk.handlers.*
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.MOBILE_NETWORK
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_CAMERA
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_CONTACT
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_GALLERY
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_LOCATION
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil.alertDialogue
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil.isNetworkAvailable
import com.fiserv.dps.mobile.sdk.utils.ThresholdLimitPreference
import kotlinx.android.synthetic.main.fragment_bridge_view.*
import java.io.ByteArrayOutputStream


/**
 * BridgeFragment takes the values from BridgeConfig and forms the complete url and loads in the WebView
 * Created by F5SP0MG on 16,June,2021
 */
open class BridgeFragment : DialogFragment {
     var activity: Activity? = null
     lateinit var config: BridgeConfig

     constructor() :super()
     constructor(activity: Activity, config: BridgeConfig , popup:Boolean){
         this.activity = activity
         this.config = config
         if(popup){
             dialog?.window?.apply {
                 resources.displayMetrics.also {
                     setLayout(it.widthPixels, (it.heightPixels * 0.8).toInt())
                     setGravity(Gravity.BOTTOM)
                 }
             }
             isCancelable = false
         }
     }

    lateinit var wView: WebView
    private val evaluateJS = { js: String -> webView.evaluateJavascript(js, null) }
    private var sharedPreferences: SharedPreferences? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_bridge_view, container, false)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null) {
            sharedPreferences = activity?.getSharedPreferences("zelle", Context.MODE_PRIVATE)

            webView.run {
                loading.visibility = VISIBLE
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.allowFileAccess = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                addJavascriptInterface(
                    Handlers(requireActivity(), this@BridgeFragment, evaluateJS),
                    "FTKAndroidInterface"
                )
                webChromeClient = object : WebChromeClient() {
                    override fun onJsAlert(
                        view: WebView?,
                        url: String?,
                        message: String?,
                        result: JsResult?
                    ): Boolean {
                        return super.onJsAlert(view, url, message, result)
                    }

                    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                        Log.d("console message from WebView","---------------->${consoleMessage?.message()}")
                        Log.d("console message from WebView","---------------->${consoleMessage?.lineNumber()}")
                        return super.onConsoleMessage(consoleMessage)
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        url: String?
                    ): Boolean {
                        loading.visibility = VISIBLE
                        wView = view!!
                        post { loadUrl(url!!.trim()) }
                        return true
                    }
                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        loading.visibility = GONE
                    }
                }



                if (isNetworkAvailable(requireContext())) {
                    post { loadUrl(config.url.trim()) }
                } else {
                    alertDialogue(requireActivity(), "", MOBILE_NETWORK, "Ok")
                }
//                this.canGoBack()
//                this.setOnKeyListener(View.OnKeyListener { v, keyCode, event ->
//                    if (keyCode == KeyEvent.KEYCODE_BACK && event.action === MotionEvent.ACTION_UP && webView.canGoBack()) {
//                        webView.goBack()
//                        return@OnKeyListener true
//                    }
//                    false
//                })
            }
        }else{
            setThreshold(THRESHOLD_LIMIT_CONTACT)
            setThreshold(THRESHOLD_LIMIT_CAMERA)
            setThreshold(THRESHOLD_LIMIT_GALLERY)
            setThreshold(THRESHOLD_LIMIT_LOCATION)
        }
    }

    /**
     * getBitmapFromUri will convert image uri to bitmap
     * @param data - Uri
     * @return Bitmap
     */
    fun getBitmapFromUri(data: Uri): Bitmap {
        if (Build.VERSION.SDK_INT < 29) {
            @Suppress("DEPRECATION")
            return MediaStore.Images.Media.getBitmap(activity?.contentResolver, data)
        } else {
            val source = ImageDecoder.createSource(activity?.contentResolver!!, data)
            return ImageDecoder.decodeBitmap(source)
        }
    }

    /**
     * This function will convert bitmap image to base64 image
     * @param bm - Bitmap
     * @return base64String
     */
    fun encodeImage(bm: Bitmap): String? {
        val byteArrayOutputStream = ByteArrayOutputStream()
        bm.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
        val b = byteArrayOutputStream.toByteArray()
        return Base64.encodeToString(b, Base64.NO_WRAP)
    }

    /**
     * setThreshold helps to store in shared preference about the threshold limit,
     * when app reached the threshold limit (i.e. when user select don't ask again option)
     * or when user get get permission from user (i.e. key:false/true)
     */
    fun setThreshold(key: String) {
        val threshold = ThresholdLimitPreference.getLimit(requireContext(), key)
        if (threshold.isNotEmpty()) {
            ThresholdLimitPreference.save(key, "false", requireContext())
        }
    }
}