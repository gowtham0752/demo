package com.fiserv.dps.mobile.sdk.bridge.model

import com.fiserv.dps.mobile.sdk.BuildConfig

/**
 * It provides the mechanism/way to create the url from the details received from parent app
 * Created by F5SP0MG on 16,June,2021
 */
class Zelle(
    applicationName: String? = "",
    baseURL: String,
    institutionId: String,
    product: String,
    ssoKey: String,
    parameters: Map<String, String>? = null
): BridgeConfig {
    override var appName = ""
    override var url = ""
    override var preCacheContacts = false
    init {
        appName = applicationName!!
        //prepare the url using passed parameters
//        if(finalUrl == ""){
        url = baseURL
        // url = "https://dhayaaperumal.github.io/demo/index.html"
        url += "?INSTITUTION_ID=$institutionId&product=$product"
        url += "&container=mobile_sdk_android&version=${BuildConfig.VERSION_NAME}&KEY=$ssoKey"
        if(parameters != null)
            url += parameters.map { it.key + "=" + it.value }.joinToString("&", "&")
//        }else{
//            url = finalUrl!!
//        }

    }
}

