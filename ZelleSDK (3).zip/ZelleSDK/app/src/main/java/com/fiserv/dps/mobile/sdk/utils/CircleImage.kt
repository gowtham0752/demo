package com.fiserv.dps.mobile.sdk.utils

import android.content.res.Resources
import android.graphics.*
import android.util.DisplayMetrics
import androidx.core.graphics.drawable.RoundedBitmapDrawable
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory
import java.util.*

/**
 * CircleImage helps to create circle bitmap image
 * Created by F6W0W4F on 09,July,2021
 */
object CircleImage {

    /**
     * generateCircleBitmap will generate the circular image
     * @param diameterDP
     * @param text
     * @return bitmap
     */
    fun generateCircleBitmap(diameterDP: Float, text: String?): Bitmap? {
        val rnd = Random()
        val currentColor: Int =
            Color.argb(100, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
        val textColor = -0x1
        val metrics: DisplayMetrics = Resources.getSystem().displayMetrics
        val diameterPixels = diameterDP * (metrics.densityDpi / 160f)
        val radiusPixels = diameterPixels / 2

        // Create the bitmap
        val output = Bitmap.createBitmap(
            diameterPixels.toInt(), diameterPixels.toInt(),
            Bitmap.Config.ARGB_8888
        )

        // Create the canvas to draw on
        val canvas = Canvas(output)
        canvas.drawARGB(0, 0, 0, 0)

        // Draw the circle
        val paintC = Paint()
        paintC.isAntiAlias = true
        paintC.color = currentColor
        canvas.drawCircle(radiusPixels, radiusPixels, radiusPixels, paintC)

        // Draw the text
        if (text != null && text.isNotEmpty()) {
            val paintT = Paint()
            paintT.color = textColor
            paintT.isAntiAlias = true
            paintT.textSize = radiusPixels * 2
            val textBounds = Rect()
            paintT.getTextBounds(text, 0, text.length, textBounds)
            canvas.drawText(
                text,
                radiusPixels - textBounds.exactCenterX(),
                radiusPixels - textBounds.exactCenterY(),
                paintT
            )
        }
        return output
    }

    /**
     * circleBitmap creating rounded bitmap drawable image
     * @param resources
     * @param bitmap
     * @return RoundedBitmapDrawable
     */
    fun circleBitmap(resources: Resources, bitmap: Bitmap): RoundedBitmapDrawable {
        val roundedBitmapDrawable: RoundedBitmapDrawable =
            RoundedBitmapDrawableFactory.create(resources, bitmap)
        roundedBitmapDrawable.isCircular = true
        return roundedBitmapDrawable
    }
}