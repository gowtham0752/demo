package com.fiserv.dps.mobile.sdk.handlers

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import androidx.print.PrintHelper
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.APPLICATION_ID
import java.io.File
import java.io.FileOutputStream

/**
 * ShareHandler created to handle the share details passed from java script.
 * This interface will be called from java script.
 * base64Image, text and url will be passed from java script.
 * sharePhoto() function used to share photo, text and url (text and url is option fields).
 * printPhoto() function used to print the qr code using printer
 * shareText() function used to share text and url (url is option field).
 * Created by F5SP0MG on 21,June,2021
 */
interface ShareHandler {
    @JavascriptInterface
    fun sharePhoto(base64Image: String, text: String?, url: String?)

    @JavascriptInterface
    fun printPhoto(base64Image: String, text: String?, url: String?)

    @JavascriptInterface
    fun shareText(text: String, url: String?)
}

/**
 * ShareHandler class has been implemented here to perform their actions
 */
class ShareHandlerImpl(private val activity: Activity) : ShareHandler {

    @JavascriptInterface
    override fun sharePhoto(base64Image: String, text: String?, url: String?) {
        shareImageOrText(base64Image, text, url)
    }

    override fun printPhoto(base64Image: String, text: String?, url: String?) {
        printImage(base64Image)
    }

    @JavascriptInterface
    override fun shareText(text: String, url: String?) {
        shareImageOrText(text = text, url = url)
    }

    /**
     * function used to print photo,
     * @param base64Image: String
     * Created by F5ZF5DH on 19,July,2021
     */
    private fun printImage(base64Image: String) {
        this.also {
            PrintHelper(activity).apply {
                scaleMode = PrintHelper.SCALE_MODE_FIT
            }.also { printHelper ->
                val imageBytes = Base64.decode(base64Image, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                printHelper.printBitmap("qr.png - test print", bitmap)
            }
        }
    }

    /**
     * shareImageORText function will be initiate intent with ACTION_SENT
     * @param base64Image
     * @param text
     * @param url
     * Created by F5ZF5DH on 15,July,2021
     */
    @SuppressLint("SetWorldReadable")
    private fun shareImageOrText(base64Image: String = "", text: String?, url: String?) {
        try {
            val intent = Intent(Intent.ACTION_SEND)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            intent.type = "*/*"
            if (base64Image.isNotEmpty()) {
                val imageBytes = Base64.decode(base64Image, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                val file = File(
                    activity.applicationContext.externalCacheDir,
                    File.separator.toString() + "Image.png"
                )
                val fOut = FileOutputStream(file)
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut)
                fOut.flush()
                fOut.close()
                file.setReadable(true, false)

                val photoURI = FileProvider.getUriForFile(
                    activity.applicationContext,
                    "$APPLICATION_ID.file_provider",
                    file
                )
                intent.putExtra(Intent.EXTRA_STREAM, photoURI)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (!text.isNullOrEmpty()) {
                intent.putExtra(Intent.EXTRA_SUBJECT, text)
            }
            if (!url.isNullOrEmpty()) {
                intent.putExtra(Intent.EXTRA_TEXT, url)
            }
            activity.startActivity(Intent.createChooser(intent, "Share image via"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}