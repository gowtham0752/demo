package com.fiserv.dps.mobile.sdk.utils

import android.content.Context

/**
 * AppComUtils is helps to set/get preference to/from the SharedPreferences
 * Created by F5SP0MG on 22,June,2021
 */
class AppComUtils {
    companion object{
        private const val PREFS_NAME = "Zelle"

        /**
         * This function helps to save preferences to SharedPreferences
         */
        fun setPreferenceString(context: Context, key:String, value: String){
            val settings = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val editor = settings.edit()
            editor.putString(key, value)
            editor.apply()
            editor.commit()
        }

        /**
         * This function helps to get preferences to SharedPreferences
         */
        fun getPreferenceString(context: Context , key: String):String{
            val pref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return pref.getString(key, "")!!
        }
    }
}