﻿using System;
using Foundation;
using UIKit;

namespace Binding
{
	// @interface MyZelle : NSObject
	[BaseType(typeof(NSObject))]
	interface MyZelle
	{
		// -(void)launchZelleSDKWithViewController:(UIViewController * _Nonnull)viewController;
		[Export("launchZelleSDKWithViewController:")]
		void LaunchZelleSDKWithViewController(UIViewController viewController);
	}
}
