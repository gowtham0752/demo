// created by Shiva kumar

import Foundation
import UIKit
var indexPathSEt = NSIndexPath()

var hiliteRow:Int = -1

protocol SidebarViewDelegate: AnyObject {
     func paySectionClicked(row: Row)
}
struct GetProfile {
static var ProfileData = NSDictionary()
}
enum Row: String {
    case FiservTurnKey
    case BillPay
    case TransferNow
    case Profile
    case Deposits
    

    init(row: Int) {
        switch row {
        case 0: self = .FiservTurnKey
        case 1: self = .BillPay
        case 2: self = .TransferNow
        case 3: self = .Profile
        case 4: self = .Deposits
       
        default:
            self = .FiservTurnKey
        }

    }
}

//var homedelegate = HomeViewController()
class SidebarView: UIView, UITableViewDelegate, UITableViewDataSource{
   
   var homeVc: HomeViewController!

    var titleArr = ["Fiserv TurnKey","Bill Pay", "Transfer Now", "Profile", "Deposits"]
     
    var rowDefaultSelected = 0

    var selectedIndexpath:IndexPath? = NSIndexPath() as IndexPath
    weak var delegate: SidebarViewDelegate?
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.clipsToBounds=true
        setupViews()
      
        self.backgroundColor = .white
        myTableView.delegate=self
        myTableView.backgroundColor = .white
        myTableView.dataSource=self
        myTableView.register(UINib.init(nibName: "menuCellXib", bundle: nil), forCellReuseIdentifier: "menuCellXib")
        myTableView.register(UINib.init(nibName: "menuHeaderCell", bundle: nil), forCellReuseIdentifier: "menuHeaderCell")
        myTableView.tableFooterView=UIView()
       //  myTableView.tableHeaderView=UIView()
        myTableView.tableHeaderView?.backgroundColor = .red

        myTableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        myTableView.allowsSelection = true
        myTableView.showsVerticalScrollIndicator=true
        myTableView.backgroundColor = UIColor.white
        self.myTableView.allowsMultipleSelection = false
        self.myTableView.contentInset = UIEdgeInsets(top:-75, left: 0, bottom: 0, right: 0)

        }
   
    override func layoutIfNeeded() {

    }
    deinit {
        NotificationCenter.default.removeObserver(self)
       print("deallocated Sidebar")
      
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if section == 0 {
            return 1
        }else if section == 1{
            return titleArr.count
        }
        return 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        if indexPath.section == 0 {
            let cell:menuHeaderCell = tableView.dequeueReusableCell(withIdentifier: "menuHeaderCell", for: indexPath) as! menuHeaderCell
                cell.backgroundColor = .white
            
            cell.signOut.setTitleColor(UIColor.darkGray, for: .normal)
            
            cell.signOut.layer.borderWidth = 0.8
            cell.signOut.layer.borderColor = (UIColor( red: 0.5, green: 0.5, blue:0, alpha: 1.0 )).cgColor
               //cell.selectionStyle = .none
            

                return cell
            }
            
        else if indexPath.section == 1{

         let cell:menuCellXib = tableView.dequeueReusableCell(withIdentifier: "menuCellXib", for: indexPath) as! menuCellXib
            cell.backgroundColor = .white
           //cell.selectionStyle = .none
            cell.lblmenu.text = titleArr[indexPath.row]
            return cell
        }
            
        return UITableViewCell()
        }
    

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

     //  DfaultLoad = false
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
            // your code here
            if indexPath.section == 0 {

          //  self.delegate?.profileClicked(row:Rowp(row: indexPath.row))
            }else if indexPath.section == 1{
              //  rowDefaultSelected = indexPath.row

                self.delegate?.paySectionClicked(row:Row(row: indexPath.row))

            }
        }
        

    }
//    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
//        let cell = tableView.cellForRow(at: indexPath)
//        if cell?.isSelected == true { // check if cell has been previously selected
//            tableView.deselectRow(at: indexPath, animated: true)
//            return nil
//        } else {
//            return indexPath
//        }
//    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 1 && indexPath.row == 0{
            
            self.myTableView.deselectRow(at:indexPath, animated: false)
       
        }
        
        
//        if indexPath.section == 1 &&  indexPath.row == 1{
//            hiliteRow = indexPath.row
//            myTableView.reloadRows(at: [indexPath], with: .top)
//
//        }
        
       // indexPathSEt = indexPath as NSIndexPath
       // let indexPath = IndexPath(item: 0, section: 1)
        
    
        
    print("Did deselect called")

        
        //guard let cell:menuCellXib = tableView.dequeueReusableCell(withIdentifier: "menuCellXib", for: indexPath) as! menuCellXib
//         else {
//        return
//        }
        
        //self.tableView(self.myTableView, didUnhighlightRowAt: indexPath)
//        let indexPath = IndexPath(row: 0, section: 1)
//        myTableView.selectRow(at: indexPath, animated: false, scrollPosition: .none)
        
       
        //deselectedCell.selectionColor = UIColor.white



    }
   
    

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {

    if section == 0 {
       return 60
        }
        else if  section == 1{
            return 50
        }
        return 0
    }

     func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        // UIView with darkGray background for section-separators as Section Footer
        let v = UIView(frame: CGRect(x: 0, y:0, width: tableView.frame.width, height: 1))
        if section == 0 {

        }else{
            v.backgroundColor = .white
            return v
        }
       return UIView()
    }
     func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 1.0
    }


    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 60
        } else {
            return 50
        }
    }

//    func tableView(_ tableView: UITableView, didHighlightRowAt indexPath: IndexPath) {
//
//        DfaultLoad = false
//        if indexPath.section == 1 && indexPath.row == 0 {
//
//
//        }else {
//            let indexPathh = IndexPath(item: 0, section: 1)
//            myTableView.reloadRows(at: [indexPathh], with: .fade)
//
//            let cell  = myTableView.cellForRow(at: indexPath)
//            cell!.backgroundColor = whilteColor
//            cell?.contentView.backgroundColor = NAVIGATIONBARCOLOR?.withAlphaComponent(0.1)
//        }
//
//        }

    
//    func tableView(_ tableView: UITableView, didUnhighlightRowAt indexPath: IndexPath) {
//        let deselectedCell = myTableView.cellForRow(at: indexPath)!
//        deselectedCell.backgroundColor = UIColor.white
//        deselectedCell.contentView.backgroundColor = UIColor.white
//    }

  

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        if section == 0 || section == 1{

        let returnedView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 25))
        returnedView.backgroundColor = .lightGray
       // label.setCustomFontAndSize(size: tltContentInfo, color: blackcolor!, fontName: CUSTOMFONTREGULAR!)

        returnedView.backgroundColor = .white
        
            return returnedView
        }else{
            return nil
        }
    }


    func setupViews() {

        self.addSubview(myTableView)
        myTableView.topAnchor.constraint(equalTo:topAnchor).isActive = true
        myTableView.leftAnchor.constraint(equalTo:leftAnchor).isActive = true
        myTableView.rightAnchor.constraint(equalTo:rightAnchor).isActive = true
        myTableView.bottomAnchor.constraint(equalTo:bottomAnchor).isActive = true

    }

    var myTableView: UITableView = {
        var table = UITableView()
        table.translatesAutoresizingMaskIntoConstraints=false
        return table
    }()

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
  
}

