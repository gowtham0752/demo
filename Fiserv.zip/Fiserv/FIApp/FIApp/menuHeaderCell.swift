//
//  menuHeaderCell.swift
//  LetPay Biz
//
//  Created by LETPAY on 31/12/20.
//  Copyright © 2020 LETPAY. All rights reserved.
//

import UIKit

class menuHeaderCell: UITableViewCell {
   
    @IBOutlet weak var signOut: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        selectedBackgroundView = {
                        let view = UIView.init()
                        return view
                    }()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    deinit {
      
    }
}
