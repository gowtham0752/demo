//
//  menuCellXib.swift
//  LetPay Biz
//
//  Created by LETPAY on 31/12/20.
//  Copyright © 2020 LETPAY. All rights reserved.
//

import UIKit

class menuCellXib: UITableViewCell {

    @IBOutlet weak var lblmenu: UILabel!
    @IBOutlet weak var img: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        let view = UIView()
          selectedBackgroundView = view
         //Configure the view for the selected state
    }
    deinit {
        
    }
    
}
