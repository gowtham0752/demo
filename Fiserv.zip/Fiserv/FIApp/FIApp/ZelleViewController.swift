//
//  ViewController.swift
//  FIApp
//
//  Created by Jayant Tiwari on 29/06/21.
//  Copyright © 2021 Fiserv. All rights reserved.
//

import UIKit
import ZelleSDK

class ZelleViewController: UIViewController {

    //Original Instance
    
    @IBOutlet weak var viewContainer: UIView!
    
    private let zelle = Zelle(
        applicationName : "ABC BANK",
        baseURL: "https://jayjt11.github.io/Sdk/index.html",
        institutionId: "some_id",
        ssoKey: "sso_key",
        parameters: [
            "key1" : "value1",
            "key2" : "value2",
            "key3" : "value3",
        ]
    )
    
    // Constructed Url
    
//    private let zelle = Zelle(
//        applicationName : "ABC BANK",
//        baseURL: "https://rxp-ui-test1.checkfreeweb.com/ftk_v21_1/",
//        institutionId: "88850059",
//        product: "Zelle",
//        ssoKey: "c8b3d9ed0d41f627a5e938fde80ac574",
//        parameters: [
//            "key1" : "value1",
//            "key2" : "value2",
//            "key3" : "value3",
//        ]
//    )

    private lazy var bridge: Bridge = {
        Bridge(
            config: zelle,
            viewController: self
        )
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let zelleFrame = CGRect(x:0, y:0, width:viewContainer.frame.width, height:viewContainer.frame.height) //desired location
        let zelleView = bridge.view(frame: zelleFrame)
        
      //  let zelleView = bridge.popup(anchor: self.view)
        
        view.addSubview(zelleView)
    }


}

