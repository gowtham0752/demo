//
//  ContactTests.swift
//  FIAppTests
//
//  Created by Jayant Tiwari on 09/08/21.
//  Copyright © 2021 Fiserv. All rights reserved.
//

import XCTest


@testable import ZelleSDK
@testable import FIApp


class ContactTests: XCTestCase {

        func testCaseOne() { // Case1: number : valid , name : valid , eMail: valid
            
            
            XCTAssertEqual("+15003635234".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham Nallasivam".isValidName(), true)
            XCTAssertEqual("gowtham$05.gg@gmail.com".isValidEmail(), true)
        }

        
        func testCaseTwo() { // Case2: number : invalid , name : valid , eMail: valid
                            //Error : Number not equal to 10
            XCTAssertEqual("+1500363523".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham Nallasivam".isValidName(), true)
            XCTAssertEqual("gowtham05.gg@gmail.com".isValidEmail(), true)
        }

        func testCaseThree() { // Case3: number : invalid , name : valid , eMail: valid
            //Error : Number start with 855 is not allowed based on regex
            XCTAssertEqual("8550036352".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham Nallasivam".isValidName(), true)
            XCTAssertEqual("gowtham05.gg@gmail.com".isValidEmail(), true)
        }

        func testCaseFour() { // Case4: number : invalid , name : valid , eMail: valid
            //Error : Number less than 10
            XCTAssertEqual("987003635".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham Nallasivam".isValidName(), true)
            XCTAssertEqual("gowtham05.gg@gmail.com".isValidEmail(), true)
        }

        
        func testCaseFive() { // Case5: number : valid , name : invalid , eMail: valid
            //Error : Name should not less than two character
            XCTAssertEqual("9870036355".isValidPhoneNumber(), true)
            XCTAssertEqual("G".isValidName(), true)
            XCTAssertEqual("gowtham05.gg@gmail.com".isValidEmail(), true)
        }

        func testCaseSix() { // Case6: number : valid , name : invalid , eMail: valid
            //Error : Name character should not greater than 30
            XCTAssertEqual("9870036355".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham Nallasivam , Dhayalu , Siva ".isValidName(), true)
            XCTAssertEqual("gowtham05.gg@gmail.com".isValidEmail(), true)
        }

        
        func testCaseSeven() { // Case7: number : valid , name : invalid , eMail: valid
            //Error : Name should not be empty
            XCTAssertEqual("9870036355".isValidPhoneNumber(), true)
            XCTAssertEqual("".isValidName(), true)
            XCTAssertEqual("gowtham05.gg@gmail.com".isValidEmail(), true)
        }

        func testCaseEight() { // Case8: number : valid , name : valid , eMail: invalid
            //Error : Missing @ Symbol
            XCTAssertEqual("9870036355".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham".isValidName(), true)
            XCTAssertEqual("gowtham05.gggmail.com".isValidEmail(), true)
        }

        func testCaseNine() { // Case9: number : valid , name : valid , eMail: invalid
            //Error : Missing domain name
            XCTAssertEqual("9870036355".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham".isValidName(), true)
            XCTAssertEqual("gowtham05.gg@".isValidEmail(), true)
        }

        func testCaseTen() { // Case10: number : valid , name : valid , eMail: invalid
            //Error : Invalid / Symbol
            XCTAssertEqual("9870036355".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham".isValidName(), true)
            XCTAssertEqual("gowtham/05.gg@gmail.com".isValidEmail(), true)
        }

        
        func testCaseEleven() { // Case11: number : valid , name : valid , eMail: valid
            //Error : Valid / mobile number skips +() and it is valid
            XCTAssertEqual("+98 (700) 36355".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham".isValidName(), true)
            XCTAssertEqual("gowtham05.gg@gmail.com".isValidEmail(), true)
        }

        func testCaseTwelve() { // Case12: number : invalid , name : valid , eMail: valid
            //Error : Invalid / mobile number contains /
            XCTAssertEqual("+98 (700/ 36355".isValidPhoneNumber(), true)
            XCTAssertEqual("Gowtham".isValidName(), true)
            XCTAssertEqual("gowtham05.gg@gmail.com".isValidEmail(), true)
        }
    
    
    
}
