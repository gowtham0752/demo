//
//  PhotoTests.swift
//  FIAppTests
//
//  Created by Datanautic on 10/08/21.
//  Copyright © 2021 Fiserv. All rights reserved.
//

import XCTest


@testable import ZelleSDK
@testable import FIApp


class PhotoTests: XCTestCase {
     func testCaseOne() { // Case1: InValid Format
          
          let base64Str = ""
         
        XCTAssertEqual(Util().validatePhoto(base64: base64Str), true)
           }

           
           

    
}
