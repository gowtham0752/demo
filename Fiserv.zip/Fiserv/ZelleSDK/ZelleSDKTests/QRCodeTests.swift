//
//  QRCodeTests.swift
//  FIAppTests
//
//  Created by Datanautic on 10/08/21.
//  Copyright © 2021 Fiserv. All rights reserved.
//

import XCTest


@testable import ZelleSDK
@testable import FIApp


class QRCodeTests: XCTestCase {
    
    
  
    func testCaseOne() { // Case1: Valid Format
        
        let contact = "{\"name\":\"Siva\", \"phone\":\"9876543213\"}"
       
        XCTAssertEqual(Util().validateQrcode(code: contact), true)
         }

         
         func testCaseTwo() { // valid format
            let contact = "{\"name\":\"Siva\", \"email\":\"siva@gmail.com\"}"
            
             XCTAssertEqual(Util().validateQrcode(code: contact), true)
         }
    
    func testCaseThree() { // Case3: invalid format
        let contact = "Sivakumar"
        
         XCTAssertEqual(Util().validateQrcode(code: contact), true)
    }

    
}
