

import UIKit

public struct MsgObject: Codable {
    var CorrelationId : String?
    var TimeStamp : String?
    var Duration : String?
    var Event : String?
    var EventResults : String?
    
    init(CorrelationId: String, TimeStamp: String, Duration: String, Event: String, EventResults: String) {
        self.CorrelationId = CorrelationId
        self.TimeStamp = TimeStamp
        self.Duration = Duration
        self.Event = Event
        self.EventResults = EventResults
    }
}
