import UIKit

public struct EventResultObject: Codable {
    var StatusCode : String?
    var MessageCode : String?
    
    init(StatusCode : String, MessageCode:String) {
        self.StatusCode = StatusCode
        self.MessageCode = MessageCode
    }
}
