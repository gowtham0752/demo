//
//  Zelle.swift
//  BridgeSDK
//
//  Created by fiserv on 5/26/21.
//

import UIKit

public class Zelle: BridgeConfig {
    public var url: String
    public var preCacheContacts = false
    
    // Original Instance
    /*
     *It provides the mechanism /way to create the url from the details received from parent app.
     */
    
    
    public init(applicationName : String, baseURL :String, institutionId: String, ssoKey: String, parameters: [String:String]) {
        UserDefaults.standard.set(applicationName, forKey: "applicationName")
 //       url = "https://jayjt11.github.io/Sdk/index.html"
        url = baseURL
        url += "?institutionId=\(institutionId)&key=\(ssoKey)"
        for param in parameters {
            url += "&\(param.key)=\(param.value)"

        }
    }
    
    // Url construction
        
//        public init(applicationName : String, baseURL :String, institutionId: String, product: String, ssoKey: String,
//            parameters: [String:String]) {
//            UserDefaults.standard.set(applicationName, forKey: "applicationName")
//            let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as! String
//            url = baseURL
//            url += "?institutionId=\(institutionId)&product=\(product)&container=zelle_sdk_ios&version=\(version)&key=\(ssoKey)"
//            for param in parameters {
//                url += "&\(param.key)=\(param.value)"
//            }
//            print("Url is \(url)")
//            print("Url is \(url)")
//        }
}
