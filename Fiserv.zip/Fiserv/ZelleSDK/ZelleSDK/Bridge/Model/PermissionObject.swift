import UIKit

public struct PermissionObject: Codable {
    var Contact : String?
    var Camera : String?
    var Gallery : String?

    
    init(Contact : String, Camera:String, Gallery:String) {
        self.Contact = Contact
        self.Camera = Camera
        self.Gallery = Gallery
    }
}
