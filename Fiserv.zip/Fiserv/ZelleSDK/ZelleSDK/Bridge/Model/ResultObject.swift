import UIKit

public struct ResultObject: Codable {
    var Msg : MsgObject?
    var DeviceInfo : DeviceInfoObject?
    var Permission : PermissionObject?
    var EventResults : EventResultObject?
  
    init(Msg : MsgObject, DeviceInfo:DeviceInfoObject, Permission:PermissionObject, EventResults:EventResultObject) {
        self.Msg = Msg
        self.DeviceInfo = DeviceInfo
        self.Permission = Permission
        self.EventResults = EventResults
    }
    
    init(Msg : MsgObject, Permission:PermissionObject, EventResults:EventResultObject) {
        self.Msg = Msg
        self.Permission = Permission
        self.EventResults = EventResults
    }
}
