import UIKit

public struct DeviceInfoObject: Codable {
    var Resolution : String?
    var Network : String?
    var OSVersion : String?
    var Model : String?
    var Device : String?
    
    init(Resolution : String, Network:String, OSVersion:String, Model:String, Device:String) {
        self.Resolution = Resolution
        self.Network = Network
        self.OSVersion = OSVersion
        self.Model = Model
        self.Device = Device
    }
}
