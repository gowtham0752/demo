//
//  Contact1.swift
//  ZelleSDK
//
//  Created by Jayant Tiwari on 08/07/21.
//  Copyright © 2021 Fiserv. All rights reserved.
//

import UIKit

public struct Contacts : Codable {
    
    var name : String?
    var phone : String?
    var email : String?
    var tokenType : String?
    
    init(name : String, phone : String, tokenType : String) {
        self.name = name
        self.phone = phone
        self.tokenType = tokenType
    }
    
    init(name : String, email : String, tokenType : String) {
        self.name = name
        self.email = email
        self.tokenType = tokenType
    }
    
}
