

import UIKit
import Foundation
import CoreTelephony

class EventTracker{
    
   static func sendEventResult(startTime: Date,  eventName:String, eventResults:Bool, permission:Bool, message:String, deviceInfo:Bool? = false){
       var eventResultValue = ""
       var permissionValue = ""
       
       if(eventResults){
           eventResultValue = "Success"
       }else{
           eventResultValue = "Failed"
       }
       
       if(permission){
           permissionValue = "Allowed"
       }else{
           permissionValue = "Denied"
       }
       
       var msgObject = MsgObject(CorrelationId: Constants.CorrelationId, TimeStamp: Util.currentTime(), Duration: Util.getTimeDifference(start: startTime, end: Date()), Event: eventName, EventResults: eventResultValue)
            
        var eventResultObject = EventResultObject(StatusCode: permissionValue, MessageCode: message)
       
       var permissionObject = PermissionObject(Contact: "\(UserDefaults.standard.bool(forKey: "contact"))", Camera: "\(UserDefaults.standard.bool(forKey: "camera"))",
                                                Gallery: "\(UserDefaults.standard.bool(forKey: "photos"))")
       
       if(deviceInfo!){
           var deviceInfoObject = DeviceInfoObject(Resolution: UIScreen.main.nativeBounds.size.debugDescription, Network: CTTelephonyNetworkInfo().subscriberCellularProvider?.carrierName ?? "", OSVersion: UIDevice.current.systemVersion, Model: UIDevice.current.model, Device: UIDevice.current.name)
           
           var resultObject = ResultObject(
               Msg: msgObject, DeviceInfo: deviceInfoObject, Permission: permissionObject, EventResults: eventResultObject)
           
           print("EventResult---------\(resultObject.convertToJson)")
       }else{
           var resultObject = ResultObject(
               Msg: msgObject, Permission: permissionObject, EventResults: eventResultObject
           )
           print("EventResult---------\(resultObject.convertToJson)")
       }
      
        
       
        
    }

}

extension Encodable {
    var convertToJson: String? {
        let jsonEncoder = JSONEncoder()
        jsonEncoder.outputFormatting = .prettyPrinted
        do {
            let jsonData = try jsonEncoder.encode(self)
            return String(data: jsonData, encoding: .utf8)
        } catch {
            return nil
        }
    }
}
