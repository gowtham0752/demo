import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  static const platform = MethodChannel('zellesdk.launch');

  @override
  Widget build(BuildContext context) {

    TextEditingController _applicationNameController = TextEditingController();
    TextEditingController _baseUrlController = TextEditingController();
    TextEditingController _institutionIdController = TextEditingController();
    TextEditingController _productController = TextEditingController();
    TextEditingController _ssoKeyController = TextEditingController();

    FocusNode _applicationNameFocus = FocusNode();
    FocusNode _baseUrlFocus = FocusNode();
    FocusNode _institutionIdFocus = FocusNode();
    FocusNode _productFocus = FocusNode();
    FocusNode _ssoKeyFocus = FocusNode();

    Map<String, String> map = new HashMap();
    map['param1'] = "1234";
    map['param2'] = "something";
    map['param3'] = "abc123";

    Map<String, String> pdData = new HashMap();
    map['pd_title'] = "PD Title";
    map['pd_message'] = "PD Meaasge";

    void _lauchZelle() async{
      String zelleResult;
      try {
        final String result = await platform.invokeMethod('launchZelle',{
          'applicationName': _applicationNameController.text,
          'baseUrl':_baseUrlController.text,
          "institutionId":_institutionIdController.text,
          'product':_productController.text,
          'ssoKey': _ssoKeyController.text,
          'appData': pdData,   //Optional
          'parameter':map});

        zelleResult = result as String;
        if(zelleResult.isNotEmpty){
          print('SessionTag-------------------${zelleResult}');
        }
      } on PlatformException catch (e) {
        zelleResult = "Failed to get result: '${e.message}'.";
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Center(
            child: Column(
              children: [
                SizedBox(height: 10,),
                Text("Welcome to Zelle"),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextFormField(
                    controller: _applicationNameController,
                    focusNode: _applicationNameFocus,
                    onFieldSubmitted: (v) {
                      FocusScope.of(context).requestFocus(_baseUrlFocus);
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter application name',
                    ),
                  ),

                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextFormField(
                    controller: _baseUrlController,
                    focusNode: _baseUrlFocus,
                    onFieldSubmitted: (v) {
                      FocusScope.of(context).requestFocus(_institutionIdFocus);
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter baseUrl',
                    ),
                  ),

                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextFormField(
                    controller: _institutionIdController,
                    focusNode: _institutionIdFocus,
                    onFieldSubmitted: (v) {
                      FocusScope.of(context).requestFocus(_productFocus);
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter institutionId',
                    ),
                  ),

                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextFormField(
                    controller: _productController,
                    focusNode: _productFocus,
                    onFieldSubmitted: (v) {
                      FocusScope.of(context).requestFocus(_ssoKeyFocus);
                    },
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter product',
                    ),
                  ),

                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextFormField(
                    controller: _ssoKeyController,
                    focusNode: _ssoKeyFocus,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter ssoKey',
                    ),
                  ),

                ),
                ElevatedButton(onPressed: _lauchZelle, child:
                Text(
                  "Launch Zelle"
                )),
              ],
            )
          ),
        ),
      ),
    );
  }
}