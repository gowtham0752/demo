//
//  LaunchZelleViewController.swift
//  Runner
//
//  Created by GOWTHAM N on 20/07/22.
//

import UIKit
import ZelleSDK
class LaunchZelleViewController: UIViewController, GenericTagDelegate {
    var getData:NSDictionary?
    var flutterResult:FlutterResult?
    var appName:String? = ""
    var baseUrl:String? = ""
    var institutionId:String? = ""
    var product:String? = ""
    var ssoKey:String? = ""
    var parameters:NSDictionary? = NSDictionary()
    var callBack:String? = ""

    
    func sessionTag(tag: String) {
        flutterResult!("\(tag)")
    }
    
    
    @IBOutlet weak var viewContainer: UIView!
    
   
//https://jayjt11.github.io/Sdk/index.html

    override func viewDidLoad() {
        super.viewDidLoad()
        Bridge.genericTag = self
        appName = getData?.value(forKey: "applicationName") as? String
        baseUrl = getData?.value(forKey: "baseUrl") as? String
        institutionId = getData?.value(forKey: "institutionId") as? String
        product = getData?.value(forKey: "product") as? String
        ssoKey = getData?.value(forKey: "ssoKey") as? String
        parameters = getData?.value(forKey: "parameter") as? NSDictionary
        
         let zelle = Zelle(
            applicationName : appName,
            baseUrl: baseUrl ?? "",
            institutionId: institutionId ?? "",
            product: product ?? "",
            ssoKey: ssoKey ?? "",
            parameters: parameters  as! [String : String]
        )

         lazy var bridge: Bridge = {
            Bridge(config: zelle,
                viewController: self
            )
        }()
        
        let zelleFrame = CGRect(x:0, y:0, width: viewContainer.frame.width, height:viewContainer.frame.height) //desired location
        let zelleView = bridge.view(frame: zelleFrame)
        
      //  let zelleView = bridge.popup(anchor: self.view)
        view.addSubview(zelleView)
    }
    

}
