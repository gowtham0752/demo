import UIKit
import Flutter

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate{
    
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
      let controller : FlutterViewController =  FlutterViewController()
      
      let navigationController = UINavigationController(rootViewController: controller)
      self.window.rootViewController = navigationController
      navigationController.isNavigationBarHidden = true
      
          let zelleChannel = FlutterMethodChannel(name: "zellesdk.launch",
                                                    binaryMessenger: controller.binaryMessenger)
            zelleChannel.setMethodCallHandler({
            (call: FlutterMethodCall, result: @escaping FlutterResult) -> Void in
              if call.method == "launchZelle" {
                  let data = call.arguments
                  let mainVC:LaunchZelleViewController = LaunchZelleViewController()
                  let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LaunchZelleViewController") as!
                  LaunchZelleViewController
                  nextVC.getData = data as? NSDictionary
                  nextVC.flutterResult = result
                  navigationController.pushViewController(nextVC, animated: true)
                
               } else {
                 result(FlutterMethodNotImplemented)
                 return
               }
          })

    GeneratedPluginRegistrant.register(with: self)
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
