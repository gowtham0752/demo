package com.mobile.dps.zelle.fiapp.zellefiapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle


class LaunchZelle : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launch_zelle)

         if (intent != null) {
             val data = intent.getSerializableExtra("data") as HashMap<*, *>
             val zelle = Zelle(
                 applicationName = data.get("applicationName") as String?,
                 baseURL = data.get("baseUrl") as String,
                 institutionId = data.get("institutionId") as String,
                 product = data.get("product") as String,
                 ssoKey = data.get("ssoKey") as String,
                 appData = data.get("appData") as Map<String, Map<String, String>>?,
                 parameters = data.get("parameter") as Map<String, String>
             )
             val bridge = Bridge(this, zelle)
             zelle.preCacheContacts = true
 //To show Bridge View
             val view = bridge.view()
             supportFragmentManager.beginTransaction().replace(R.id.lay_view, view).commit()

 //To show Bridge Popup
//             val popup = bridge.popup()
//             popup.show(supportFragmentManager  , popup.tag)
         }
    }
}