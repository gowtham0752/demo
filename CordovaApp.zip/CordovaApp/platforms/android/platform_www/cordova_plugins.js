cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "com.example.sample.plugin.pluginName",
      "file": "plugins/com.example.sample.plugin/www/pluginName.js",
      "pluginId": "com.example.sample.plugin",
      "clobbers": [
        "pluginName"
      ]
    }
  ];
  module.exports.metadata = {
    "com.example.sample.plugin": "0.0.1"
  };
});