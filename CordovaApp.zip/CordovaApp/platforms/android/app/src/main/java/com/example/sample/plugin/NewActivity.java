package com.example.sample.plugin;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge;
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle;
import com.fiserv.dps.mobile.sdk.bridge.view.BridgeView;

import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.CordovaInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import io.cordova.hellocordova.R;


public class NewActivity extends AppCompatActivity {
    String finalUrl, appName, institutionId, sso, baseUrl, product;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String package_name = getApplication().getPackageName();
        setContentView(getApplication().getResources().getIdentifier("activity_new", "layout", package_name));
        Intent intent = getIntent();
        if (intent != null){
            finalUrl = intent.getStringExtra("finalUrl");
            appName = intent.getStringExtra("appName");
            institutionId = intent.getStringExtra("institutionId");
            sso = intent.getStringExtra("sso");
            baseUrl = intent.getStringExtra("baseUrl");
            product = intent.getStringExtra("product");
        }
        Map<String,String> map=new HashMap<String,String>();
        map.put("param1","1234");
        map.put("param2","something");
        map.put("param3","abc123");
        Zelle zelle = new Zelle(
                "8888002",
                "aa248ec9dfac7a8add7280f001b3729",
                map
        );
        Bridge bridge = new Bridge(NewActivity.this, zelle);
        zelle.setPreCacheContacts(true);
        BridgeView view1 = bridge.view();
        // BridgeView view = bridge.view();
        getSupportFragmentManager().beginTransaction().replace(R.id.textView, view1).commit();
        //getSupportFragmentManager().beginTransaction().replace(R.id.textView,view1).commit()
    }
}