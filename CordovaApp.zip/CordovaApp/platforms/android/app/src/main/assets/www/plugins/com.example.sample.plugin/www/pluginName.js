cordova.define("com.example.sample.plugin.pluginName", function(require, exports, module) {
var exec = require('cordova/exec');

function plugin() {

}


plugin.prototype.new_activity = function(finalUrl,appName,institutionId,sso,baseUrl,product) {

var options = {};
  options.finalUrl = finalUrl;
  options.appName = appName;
  options.institutionId = institutionId;
  options.sso = sso;
  options.baseUrl = baseUrl;
  options.product = product;
    exec(function(res){}, function(err){}, "pluginName", "new_activity", [options]);
}

module.exports = new plugin();
});
