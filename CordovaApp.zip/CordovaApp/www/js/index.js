var app = {
    initialize: function() {
        this.bindEvents();
    },
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
        document.getElementById("click").addEventListener("click", openZelle);
    }
};

app.initialize();

function openZelle(){
alert("hai")
console.log('---------------->Running ');
  pluginName.new_activity("", "Demo Bank", "mob", "sso", "https://gowtham0752.github.io/DemoHTML/","zelle");
}
