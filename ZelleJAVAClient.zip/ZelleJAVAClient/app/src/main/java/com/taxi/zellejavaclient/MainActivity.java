package com.taxi.zellejavaclient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.print.PrintHelper;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.FrameLayout;

import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge;
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment;
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle;
import com.fiserv.dps.mobile.sdk.bridge.view.BridgePopup;
import com.fiserv.dps.mobile.sdk.bridge.view.BridgeView;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    FrameLayout frameLayout ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       frameLayout = findViewById(R.id.lay_view);
        Map<String,String> map=new HashMap<String,String>();
        map.put("param1","1234");
        map.put("param2","something");
        map.put("param3","abc123");

        Zelle zelle = new Zelle(
                "DemoBank",
                "https://dhayaaperumal.github.io/demo/index.html",
                "8888002",
                "aa248ec9dfac7a8add7280f001b3729",
                "https://dhayaaperumal.github.io/demo/index.html",
                 null
        );

            Bridge bridge = new Bridge(MainActivity.this, zelle);
            zelle.setPreCacheContacts(true);
            BridgeView view = bridge.view();
//        frameLayout.post(new Runnable() {
//                       @Override
//                       public void run() {
//                           Log.d("Height", "------------------"+ frameLayout.getHeight());
//                           Log.d("Width", "------------------"+ frameLayout.getWidth());
//                       }
//                   });
           // view.show(getSupportFragmentManager(), view.getTag());
            getSupportFragmentManager().beginTransaction().replace(R.id.lay_view, view).commit();
    }
}