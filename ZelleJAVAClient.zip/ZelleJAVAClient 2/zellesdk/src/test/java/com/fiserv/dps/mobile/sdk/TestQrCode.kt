package com.fiserv.dps.mobile.sdk

import com.fiserv.dps.mobile.sdk.utils.QrUtils.checkQrCode
import junit.framework.TestCase
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class TestQrCode {

    @Test
    fun testCaseOne() { // Case1: valid format
        val contact = "{\"email\":\"name@gmail.com\",\"name\":\"name\"}"
        TestCase.assertEquals(checkQrCode(contact), true)

    }

    @Test
    fun testCaseTwo() { // Case2: Invalid format
        val contact = "name"
        TestCase.assertEquals(checkQrCode(contact), true)

    }
}