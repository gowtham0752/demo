package com.fiserv.dps.mobile.sdk

import com.fiserv.dps.mobile.sdk.utils.Validator.validateEmail
import com.fiserv.dps.mobile.sdk.utils.Validator.validateMobileNumber
import com.fiserv.dps.mobile.sdk.utils.Validator.validateName
import junit.framework.TestCase.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class TestContact {

    @Test
    fun testCaseOne() { // Case1: number : valid , name : valid , eMail: valid
        assertEquals(validateMobileNumber("+15003635234"), true)
        assertEquals(validateName("Gowtham Nallasivam"), true)
        assertEquals(validateEmail("gowtham$05.gg@gmail.com"), true)
    }

    @Test
    fun testCaseTwo() { // Case2: number : invalid , name : valid , eMail: valid
        //Error : Number not equal to 10
        assertEquals(validateMobileNumber("+1500363523"), true)
        assertEquals(validateName("Gowtham Nallasivam"), true)
        assertEquals(validateEmail("gowtham05.gg@gmail.com"), true)
    }

    @Test
    fun testCaseThree() { // Case3: number : invalid , name : valid , eMail: valid
        //Error : Number start with 855 is not allowed based on regex
        assertEquals(validateMobileNumber("8550036352"), true)
        assertEquals(validateName("Gowtham Nallasivam"), true)
        assertEquals(validateEmail("gowtham05.gg@gmail.com"), true)
    }

    @Test
    fun testCaseFour() { // Case4: number : invalid , name : valid , eMail: valid
        //Error : Number less than 10
        assertEquals(validateMobileNumber("987003635"), true)
        assertEquals(validateName("Gowtham Nallasivam"), true)
        assertEquals(validateEmail("gowtham05.gg@gmail.com"), true)
    }

    @Test
    fun testCaseFive() { // Case5: number : valid , name : invalid , eMail: valid
        //Error : Name should not less than two character
        assertEquals(validateMobileNumber("9870036355"), true)
        assertEquals(validateName("G"), true)
        assertEquals(validateEmail("gowtham05.gg@gmail.com"), true)
    }

    @Test
    fun testCaseSix() { // Case6: number : valid , name : invalid , eMail: valid
        //Error : Name character should not greater than 30
        assertEquals(validateMobileNumber("9870036355"), true)
        assertEquals(validateName("Gowtham Nallasivam , Dhayalu , Siva "), true)
        assertEquals(validateEmail("gowtham05.gg@gmail.com"), true)
    }

    @Test
    fun testCaseSeven() { // Case7: number : valid , name : invalid , eMail: valid
        //Error : Name should not be empty
        assertEquals(validateMobileNumber("9870036355"), true)
        assertEquals(validateName(""), true)
        assertEquals(validateEmail("gowtham05.gg@gmail.com"), true)
    }

    @Test
    fun testCaseEight() { // Case8: number : valid , name : valid , eMail: invalid
        //Error : Missing @ Symbol
        assertEquals(validateMobileNumber("9870036355"), true)
        assertEquals(validateName("Gowtham"), true)
        assertEquals(validateEmail("gowtham05.gggmail.com"), true)
    }

    @Test
    fun testCaseNine() { // Case9: number : valid , name : valid , eMail: invalid
        //Error : Missing domain name
        assertEquals(validateMobileNumber("9870036355"), true)
        assertEquals(validateName("Gowtham"), true)
        assertEquals(validateEmail("gowtham05.gg@"), true)
    }

    @Test
    fun testCaseTen() { // Case10: number : valid , name : valid , eMail: invalid
        //Error : Invalid / Symbol
        assertEquals(validateMobileNumber("9870036355"), true)
        assertEquals(validateName("Gowtham"), true)
        assertEquals(validateEmail("gowtham/05.gg@gmail.com"), true)
    }

    @Test
    fun testCaseEleven() { // Case11: number : valid , name : valid , eMail: valid
        //Error : Valid / mobile number skips +() and it is valid
        assertEquals(validateMobileNumber("+98 (700) 36355"), true)
        assertEquals(validateName("Gowtham"), true)
        assertEquals(validateEmail("gowtham05.gg@gmail.com"), true)
    }

    @Test
    fun testCaseTwelve() { // Case12: number : invalid , name : valid , eMail: valid
        //Error : Invalid / mobile number contains /
        assertEquals(validateMobileNumber("+98 (700/ 36355"), true)
        assertEquals(validateName("Gowtham"), true)
        assertEquals(validateEmail("gowtham05.gg@gmail.com"), true)
    }
}