package com.fiserv.dps.mobile.sdk.bridge.model

/**
 * It contains the configuration parameters
 * Created by F5SP0MG on 16,June,2021
 */
interface BridgeConfig {
    var appName: String
    var url: String
    var icon: String
    var text: String
    var textColor: String
    var bgColor:String
    var appData: Map<String, Map<String, String>>
    var preCacheContacts: Boolean
}
