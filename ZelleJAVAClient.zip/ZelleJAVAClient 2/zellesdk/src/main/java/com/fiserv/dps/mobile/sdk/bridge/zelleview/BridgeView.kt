package com.fiserv.dps.mobile.sdk.bridge.zelleview

import android.app.Activity
import android.content.Context
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.bridge.model.BridgeConfig
import com.fiserv.dps.mobile.sdk.interfaces.GenericTag

/**
 * Will be shown to user as a view which will be integrated to the activity/fragment in the parent app
 * Created by F5SP0MG on 16,June,2021
 */
class BridgeView: BridgeFragment{
    companion object{
        lateinit var genericTag: GenericTag
    }
    constructor() : super()
    constructor(activity: Context, config: BridgeConfig): super(activity, config, false)
}