package com.fiserv.dps.mobile.sdk.interfaces

interface GenericTag {
    fun sessionTag(tag: String)
}