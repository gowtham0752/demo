package com.fiserv.dps.mobile.sdk.bridge.model

data class DeviceInfoModel(
    var name:String? = null,
    var mcc:String? = null,
    var mnc:String? = null,
    var version:String? = null,
    var model:String? = null,
    var resolution:String? = null
)

data class DeviceResolution(
    var height:Any? = null,
    var width:Any? = null
)
