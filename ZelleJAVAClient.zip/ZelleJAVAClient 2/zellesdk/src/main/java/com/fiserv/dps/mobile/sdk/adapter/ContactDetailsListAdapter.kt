package com.fiserv.dps.mobile.sdk.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import com.fiserv.dps.mobile.sdk.R
import com.fiserv.dps.mobile.sdk.R.layout.adapter_contact_details
import kotlinx.android.synthetic.main.adapter_contact_details.view.*
import java.util.*

/**
 * ContactDetailsListAdapter load the contact details in  RecyclerView using Arraylist
 * @param  context: Activity
 * @param model: Arraylist
 * @param click: clickListener
 * Created by F6W0W4F on 09,July,2021
 */
class ContactDetailsListAdapter(
    val context: Activity,
    private val model: ArrayList<String>,
    private var click: ContactsClick
) : ArrayAdapter<String>(context, adapter_contact_details, model) {
    @SuppressLint("ViewHolder", "InflateParams")
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(adapter_contact_details, null, true)
        val value = model[position]
        if (value.startsWith("@")) {
            val number = value.drop(1)
           // value = value.drop(1)
            rowView.tv_mobile.text = number
            rowView.img_call.setImageResource(R.drawable.call)
            rowView.image_message.setImageResource(R.drawable.message)
        } else {
            rowView.tv_mobile.text = value
            rowView.img_call.setImageResource(R.drawable.ic_baseline_mail_outline_24)
        }

        rowView.tv_mobile.setOnClickListener {
            click.getContact(value)
        }
        return rowView
    }

    /**
     * interface created for passing selected contact to the contact detail activity
     */
    interface ContactsClick {
        fun getContact(value: String)
    }
}