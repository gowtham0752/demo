package com.fiserv.dps.mobile.sdk.handlers

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.utils.Constants
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_CAMERA_FOR_PHOTO_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_GALLERY_FOR_PHOTO_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_GALLERY
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil
import com.fiserv.dps.mobile.sdk.utils.Validator.validateBitmap
import java.io.File
import androidx.annotation.RequiresApi


/**
 * PhotosHandler created to handle the image from the device, using camera and gallery.
 * This interface will be called from java script and
 * max width and max height will be passed from java script.
 * takePhoto() function used to capture photo using camera.
 * selectFromPhotos() function used to get photo from gallery/external storage.
 * Created by F5SP0MG on 21,June,2021
 */
interface PhotosHandler {
    @JavascriptInterface
    fun takePhoto(maxWidth: Int, maxHeight: Int)
    @JavascriptInterface
    fun selectFromPhotos(maxWidth: Int, maxHeight: Int)
}

/**
 * PhotoHandler class has been implemented here to perform their actions
 */
class PhotosHandlerImpl(
    private val fragment: BridgeFragment,
    private val evaluateJS: (String) -> Unit
) : PhotosHandler {

    private lateinit var imageUri: Uri
    private var filePath: File = File(fragment.requireContext().cacheDir, "Pic.jpg")
    private var maxWidth: Int = 0
    private var maxHeight: Int = 0

    /**
     * Function used to get result of capture photo using camera and convert image  to base64
     * Created by F5ZF5DH on 15,July,2021
     */
    private val cameraActivityResultLauncher =
        fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            try {
                var bitmap = result.data!!.extras?.get("data") as Bitmap
                    bitmap = Bitmap.createScaledBitmap(bitmap, maxWidth, maxHeight, false)
                    if (validateBitmap(bitmap)){
                        callbackPhoto(fragment.encodeImage(bitmap))
                    }

                } catch (e: Exception) {
                    callbackPhoto("No Result Found")
                    e.printStackTrace()
                }
            }else {
                /**
                 * this Alert dialogue open  permission enable setting for storage
                 */
                PermissionUtil.alertDialogue(
                    fragment = fragment,
                    message = Constants.NO_DATA_FOUND,
                    code = Constants.VALID_USER_NAME
                )
            }
        }

    /**
     * This cameraActivityResultForPermission check threshold limit and enable read external storage
     * Created by F5ZF5DH on 15,July,2021
     */
    private val cameraActivityResultForPermission = fragment.registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it){
            fragment.setThreshold(Constants.THRESHOLD_LIMIT_CAMERA)
            openCamera()
        }else{
            PermissionUtil.checkUserRequestedDoNotAskAgainCamera(fragment,
                REQUEST_CAMERA_FOR_PHOTO_SETTINGS, cameraSettingsActivityResultLauncher)
        }
    }

    /**
     * This cameraSettingsActivityResultLauncher check  read external storage permission
     *  open camera intent
     *  Created by F5ZF5DH on 15,July,2021
     */
    private val cameraSettingsActivityResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (PermissionUtil.checkPermissionForCamera(fragment.requireContext())){
            openCamera()
        }
    }

    /**
     * This photoActivityResultLauncher get gallery image uri and  encode the image
     * Created by F5OWV6C on 15,July,2021
     */
    private val photoActivityResultLauncher =
        fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                try {
                    var bitmap: Bitmap = fragment.getBitmapFromUri(result.data?.data!!)
                    bitmap = Bitmap.createScaledBitmap(bitmap, maxWidth, maxHeight, false)
                    if (validateBitmap(bitmap)){
                        callbackPhoto(fragment.encodeImage(bitmap))
                    }
                } catch (e: Exception) {
                    callbackPhoto("No Result Found")
                    e.printStackTrace()
                }
            }
        }

    /**
     * Threshold limit check for storage
     * Intent pass to open gallery otherwise intent pass to open gallery permission setting from native OS
     * Created by F5OWV6C on 15,July,2021
     */
    private val storageActivityResultForPermission = fragment.registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it){
            fragment.setThreshold(THRESHOLD_LIMIT_GALLERY)
            openGallery()
        }else{
            PermissionUtil.checkUserRequestedDoNotAskAgainCamera(fragment,
                REQUEST_READ_GALLERY_FOR_PHOTO_SETTINGS, storageSettingsActivityResultLauncher)
        }
    }

    /**
     * storageSettingsActivityResultLauncher called to open gallery when the permission is enabled
     * Created by F5OWV6C on 15,July,2021
     */
    private val storageSettingsActivityResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (PermissionUtil.checkPermissionForGallery(fragment.requireContext())){
            openGallery()
        }
    }

    /**
     * javascript call takePhoto function to get photo from camera
     * @param maxWidth: Int
     * @param maxHeight: Int
     */
    @JavascriptInterface
    override fun takePhoto(maxWidth: Int, maxHeight: Int) {

        this.maxWidth = maxWidth
        this.maxHeight = maxHeight

        if (PermissionUtil.checkPermissionForCamera(fragment.requireContext())) {
            openCamera()
        } else {
            if (fragment.config.appData.containsKey("pd_camera")) {
                val ss = fragment.config.appData["pd_camera"]
                PermissionUtil.alertDialogue(
                    fragment = fragment,
                    title = ss!!["title"].toString(),
                    message = ss["message"].toString(),
                    code = Constants.CAMERA_PERMISSION_DETAILS,
                    positiveButton = Constants.AGREE,
                    negativeButton = Constants.SKIP,
                    pdARL = cameraActivityResultForPermission
                )
            }else{
                PermissionUtil.alertDialogue(
                    fragment = fragment,
                    title = "",
                    message = "",
                    code = Constants.CAMERA_PERMISSION_DETAILS,
                    positiveButton = Constants.AGREE,
                    negativeButton = Constants.SKIP,
                    pdARL = cameraActivityResultForPermission
                )
            }
           // cameraActivityResultForPermission.launch(Manifest.permission.CAMERA)
        }
    }

    /**
    * javascript call selectFromPhotos function   to get photo from gallery
    * @param maxWidth: Int
    * @param maxHeight: Int
    */
    @JavascriptInterface
    override fun selectFromPhotos(maxWidth: Int, maxHeight: Int) {

        this.maxWidth = maxWidth
        this.maxHeight = maxHeight

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q){
            if(PermissionUtil.checkPermissionForGallery(fragment.requireContext())){
                openGallery()
            }else{
                if (fragment.config.appData.containsKey("pd_gallery")) {
                    val ss = fragment.config.appData["pd_gallery"]
                    PermissionUtil.alertDialogue(
                        fragment = fragment,
                        title = ss!!["title"].toString(),
                        message = ss["message"].toString(),
                        code = Constants.GALLERY_PERMISSION_DETAILS,
                        positiveButton = Constants.AGREE,
                        negativeButton = Constants.SKIP,
                        pdARL = storageActivityResultForPermission
                    )
                }else{
                    PermissionUtil.alertDialogue(
                        fragment = fragment,
                        title = "",
                        message = "",
                        code = Constants.GALLERY_PERMISSION_DETAILS,
                        positiveButton = Constants.AGREE,
                        negativeButton = Constants.SKIP,
                        pdARL = storageActivityResultForPermission
                    )
                }
               // storageActivityResultForPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }else{
            if(PermissionUtil.checkPermissionForMedia(fragment.requireContext())){
                openChooser()
            }else{
                if (fragment.config.appData.containsKey("pd_gallery")) {
                    val ss = fragment.config.appData["pd_gallery"]
                    PermissionUtil.alertDialogue(
                        fragment = fragment,
                        title = ss!!["title"].toString(),
                        message = ss["message"].toString(),
                        code = Constants.SCOPED_GALLERY_PERMISSION_DETAILS,
                        positiveButton = Constants.AGREE,
                        negativeButton = Constants.SKIP,
                        pdARL = mediaStoreActivityResultForPermission
                    )
                }else{
                    PermissionUtil.alertDialogue(
                        fragment = fragment,
                        title = "",
                        message = "",
                        code = Constants.SCOPED_GALLERY_PERMISSION_DETAILS,
                        positiveButton = Constants.AGREE,
                        negativeButton = Constants.SKIP,
                        pdARL = mediaStoreActivityResultForPermission
                    )
                }
               // mediaStoreActivityResultForPermission.launch(Manifest.permission.ACCESS_MEDIA_LOCATION)
            }
        }
    }

    private fun openChooser(){
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        photoActivityResultLauncher.launch(Intent.createChooser(intent, "Select Picture"))
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private val mediaStoreActivityResultForPermission = fragment.registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it){
            fragment.setThreshold(Constants.THRESHOLD_LIMIT_MEDIA)
            openChooser()
        }else{
//            val threshold = ThresholdLimitPreference.getLimit(fragment.requireContext(),
//                Constants.THRESHOLD_LIMIT_MEDIA
//            )
//            if (threshold.isEmpty() || threshold.equals("false", true)){
//                val jo = JSONObject()
//                jo.put("user_action", "denied")
//                jo.put("qr_value", "")
//                callbackPhoto(jo)
//                PermissionUtil.callbackPermission(fragment, evaluateJS)
//            }
            PermissionUtil.checkUserRequestedDoNotAskAgainMedia(fragment,
                Constants.REQUEST_READ_QR_MEDIA_PERMISSION_SETTINGS, mediaStoreSettingsResultLauncher)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private val mediaStoreSettingsResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (PermissionUtil.checkPermissionForMedia(fragment.requireContext())){
            openChooser()
       }
 //       else{
//            val jo = JSONObject()
//            jo.put("user_action", "denied")
//            jo.put("qr_value", "")
//            callbackPhoto(jo)
//            PermissionUtil.callbackPermission(fragment, evaluateJS)
//        }
    }

    /**
     * openGallery function will initiate the intent to select image from gallery/external storage
     * Created by F5OWV6C on 15,July,2021
     */
    private fun openGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        if (filePath.exists()) {
            filePath.delete()
            filePath.createNewFile()
        }
//        imageUri = FileProvider.getUriForFile(
//            fragment.requireContext(),
//            "$APPLICATION_ID.file_provider",
//            filePath
//        )
        imageUri = Uri.fromFile(filePath)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
        intent.type = "image/*"
        photoActivityResultLauncher.launch(intent)
    }

    /**
     * openCamera function will initiate the intent to open camera to capture image
     * Created by F5ZF5DH on 15,July,2021
     */
    private fun openCamera() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(fragment.requireContext().packageManager!!) == null) {
            Toast.makeText(fragment.requireContext(), "Error while taking picture", Toast.LENGTH_LONG).show()
            return
        }

        try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            cameraActivityResultLauncher.launch(intent)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * callbackPhoto will return captured/selected photo to the WebView,
     * @param base64
     * Created by F5ZF5DH on 15,July,2021
     */
    private fun callbackPhoto(base64: String?) {
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackPhoto({photo: '${base64}'})")
        }, 1000)
    }
}