package com.fiserv.dps.mobile.sdk.bridge.model

import android.app.Activity
import android.content.Context
import com.fiserv.dps.mobile.sdk.bridge.zelleview.BridgePopup
import com.fiserv.dps.mobile.sdk.bridge.zelleview.BridgeView

/**
 * Bridge contains the views(BridgeView and BridgePopup)
 * Created by F5SP0MG on 16,June,2021
 */
class Bridge(
    private var activity: Context,
    private var config: BridgeConfig
) {
    fun view() = BridgeView(activity, config)
    fun popup() = BridgePopup(activity, config)
}