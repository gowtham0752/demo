package com.fiserv.dps.mobile.sdk.utils


import android.annotation.SuppressLint
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

/**
 * Contact handler will use the functions for TimerPickerUtil
 * Created by F6W0W4F on 26,July,2021
 */
object TimePickerUtil {
    const val TIME_PATTERN = "MM/dd/yyyy HH:mm:ss"

    private var startTime = Date()
    private var endTime = Date()

    /**
     * getCurrentTime() will return current time
     */
    @SuppressLint("SimpleDateFormat")
    fun getCurrentTime(): String {
        val format = SimpleDateFormat(TIME_PATTERN)
        val today = Date()
        return format.format(today)
    }

    /**
     * getExtraHourWithTimeGiven() will return remaining time from cached time
     */
    @SuppressLint("SimpleDateFormat")
    fun getExtraHourWithTimeGiven(hour: Int, time: String): String {
        val format = SimpleDateFormat(TIME_PATTERN)
        var today: Date = format.parse(time)!!
        val c = Calendar.getInstance()
        c.time = today
        c.add(Calendar.HOUR, hour)
        today = c.time
        return format.format(today)
    }

    /**
     * timeDifferenceInHour() will return the  array with hours and minutes
     */
    @SuppressLint("SimpleDateFormat")
    fun timeDifferenceInHour(startTime:String, endTime:String): Array<Long?> {
        val format = SimpleDateFormat(TIME_PATTERN)
        val time = arrayOfNulls<Long>(2)
        try {
            this.startTime = format.parse(startTime)!!
            this.endTime = format.parse(endTime)!!

        } catch (e: ParseException) {
            e.printStackTrace()
        }
        val difference: Long = this.startTime.time - this.endTime.time
        val days: Long = (difference / (1000 * 60 * 60 * 24))
        var hours: Long = ((difference - 1000 * 60 * 60 * 24 * days) / (1000 * 60 * 60))
        var min = (difference - 1000 * 60 * 60 * 24 * days - 1000 * 60 * 60 * hours).toInt() / (1000 * 60).toLong()
        //val sec = (difference - 1000 * 60 * 60 * 24 * days - 1000 * 60 * 60 * hours - 1000 * 60 * min).toInt() / 1000.toLong()
        if(hours < 0){
            hours = 0
        }
        if (min < 0){
            min = 0
        }
        time[0] = hours
        time[1] = min
        return time
    }
}