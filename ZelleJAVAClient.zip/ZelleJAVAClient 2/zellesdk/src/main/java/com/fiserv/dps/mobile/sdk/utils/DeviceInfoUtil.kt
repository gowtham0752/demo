package com.fiserv.dps.mobile.sdk.utils

import android.content.Context
import android.net.wifi.SupplicantState
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.telephony.TelephonyManager
import android.text.TextUtils
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.WindowManager
import androidx.core.content.ContextCompat.getSystemService
import com.fiserv.dps.mobile.sdk.bridge.model.DeviceInfoModel
import com.fiserv.dps.mobile.sdk.bridge.model.DeviceResolution
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil.isLocationEnabled

/**
 * DeviceInfoUtil helps to get Device Information
 * Created by F6W0W4F on 10/22/2021
 */
object DeviceInfoUtil {

    /**
     * getCarrier() - To get the Mobile network name, mcc and mnc number
     * based on the network operators
     */
    fun getCarrier(context: Context):DeviceInfoModel{
        val carrierInfo = DeviceInfoModel()
        val telephonyManager = getSystemService(context , TelephonyManager::class.java)
        val networkOperator = telephonyManager!!.simOperator
        if(!TextUtils.isEmpty(networkOperator)){
            carrierInfo.name = telephonyManager.simOperatorName
            carrierInfo.mcc = networkOperator.substring(0,3)
            carrierInfo.mnc = networkOperator.substring(3)
        }
       return carrierInfo
    }

    /**
     * getOs() - Get the device version name and version number
     */
    fun getOs():DeviceInfoModel{
        val oSInfo = DeviceInfoModel()
        val fields = Build.VERSION_CODES::class.java.fields
        fields.filter { it.getInt(Build.VERSION_CODES::class.java) == Build.VERSION.SDK_INT }
              .forEach {oSInfo.name = it.name}
        oSInfo.version = Build.VERSION.RELEASE

        return oSInfo
    }

    /**
     * getPhoneInfo() - Get mobile name, mobile model and mobile screen resolution
     */
    fun getPhoneInfo(context: Context):DeviceInfoModel{
        val phoneInfo = DeviceInfoModel()
        phoneInfo.name = Build.MANUFACTURER
        phoneInfo.model = Build.PRODUCT
        phoneInfo.resolution = "${getScreenResolution(context).width},${getScreenResolution(context).height}"
        return phoneInfo
    }

    /**
     * getSSID() - Get the Wi-Fi name when Wi-Fi is connected through device
     */
    fun getSSID(context: Context):String{
        if(PermissionUtil.checkPermissionForLocation(context)){
            if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.P || isLocationEnabled(context)){

                val wifiManager = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val wifiInfo: WifiInfo = wifiManager.connectionInfo
                if (wifiInfo.supplicantState == SupplicantState.COMPLETED){
                    return wifiInfo.ssid.replace("\"", "")
                }
            }
        }
        return ""
    }

    /**
     * getScreenResolution() - Get device resolution size in pixels
     */
    fun getScreenResolution(context: Context): DeviceResolution {
        val deviceResolution = DeviceResolution()

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
            val display:Display = context.display!!
            val displayMetrics = DisplayMetrics()
            display.getRealMetrics(displayMetrics)
            val density = context.resources.displayMetrics.density
            deviceResolution.height = displayMetrics.heightPixels / density
            deviceResolution.width = displayMetrics.widthPixels / density
        } else{
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val display:Display = wm.defaultDisplay
            val metrics = DisplayMetrics()
            display.getMetrics(metrics)
            deviceResolution.height = metrics.heightPixels
            deviceResolution.width = metrics.widthPixels
        }

        return deviceResolution
    }
}