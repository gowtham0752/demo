package com.fiserv.dps.mobile.sdk.utils

/**
 * constant values are stored in Constants
 * Created by F5SP0MG on 22,June,2021
 */
class Constants {

    companion object{
        const val DEFAULT_LOADER_COLOR = "#A1808080"
        const val APPLICATION_ID = "com.fiserv.dps.mobile.sdk"
        const val ZELLE_TRADEMARK = "\u00AE"
        const val PHONE_PATTERN = "^(?!0|1|000|800|844|855|866|877|888)\\d{10}$"
        const val PHONE_PATTERN_TWO = "[0-9\\.\\-\\+\\,\\(\\)\\ ]+"
        const val EMAIL_PATTERN = "[_A-Za-z0-9\$]+([\\.\\-][_A-Za-z0-9\$]+)*@[A-Za-z0-9]+([\\.\\-][A-Za-z0-9]+)*\\.[A-Za-z]{2,4}\$"
        const val CONTACT_DENY_MESSAGE : String = "To access contacts, you need to enable contacts permission from settings"
        const val INVALID_CONTACT_NAME : String = "Invalid Contact Name"
        const val INVALID_CONTACT_DETAIL : String = "Invalid Contact Detail"
        const val MOBILE_NETWORK : String = "Mobile data is turned off, Turn on the mobile data to proceed"
        const val CAMERA_DENY_MESSAGE : String = "To access camera, you need to enable camera permission from settings"
        const val LOCATION_DENY_MESSAGE : String = "To access location, you need to enable location permission from settings"
        const val GPS_DENY_MESSAGE : String = "To access location, you need to enable GPS"
        const val GALLERY_DENY_MESSAGE : String = "To access storage, you need to enable storage permission from settings"
        const val MEDIA_DENY_MESSAGE : String = "To access storage, you need to enable files and media permission from settings"
        const val SESSION_TIME_OUT_MESSAGE = "The Session will be closed soon. Do you want to continue?"
        const val THRESHOLD_LIMIT_CONTACT : String = "threshold_limit_contact"
        const val THRESHOLD_LIMIT_CAMERA : String = "threshold_limit_camera"
        const val THRESHOLD_LIMIT_GALLERY : String = "threshold_limit_gallery"
        const val THRESHOLD_LIMIT_MEDIA : String = "threshold_limit_media"
        const val THRESHOLD_LIMIT_LOCATION : String = "threshold_limit_location"
        const val NO_DATA_FOUND : String = "No Data Found"
        const val INVALID_QR_CODE : String = "Invalid QR Code"
        const  val CONTACT_DETAILS : String = "contact_details"
        const  val SCAN_RESULT : String = "scan_result"
        const  val CACHING_TIME : String = "caching_time"
        const  val CACHED_CONTACTS : String = "cached_contacts"
        const val AGREE:String = "Agree"
        const val SKIP : String = "Skip"
        const val CONTACT_PERMISSION_TITLE : String = "We would like to access your phone contacts"
        const val CONTACT_PERMISSION_MESSAGE : String = "We only sync phone numbers and email addresses from your contact list to help you add and pay a new recipient in Zelle"
        const val CAMERA_PERMISSION_TITLE : String = "We would like to access your phone camera"
        const val CAMERA_PERMISSION_MESSAGE : String = "We only scan qr to help you add and pay a new recipient in Zelle"
        const val GALLERY_PERMISSION_TITLE : String = "We would like to access your phone gallery"
        const val GALLERY_PERMISSION_MESSAGE : String = "We only sync qr code images from your gallery to help you add and pay a new recipient in Zelle"
        const val REQUEST_READ_CONTACT_PERMISSION_SETTINGS = 101
        const val REQUEST_READ_ALL_CONTACT_PERMISSION_SETTINGS = 102
        const val REQUEST_READ_QR_CAMERA_PERMISSION_SETTINGS = 103
        const val REQUEST_READ_QR_GALLERY_PERMISSION_SETTINGS = 104
        const val REQUEST_READ_QR_MEDIA_PERMISSION_SETTINGS = 110
        const val REQUEST_READ_GALLERY_FOR_PHOTO_SETTINGS = 105
        const val REQUEST_CAMERA_FOR_PHOTO_SETTINGS = 106
        const val REQUEST_LOCATION_PERMISSION_SETTINGS = 107
        const val ENABLE_GPS = 108
        const val ENABLE_MOBILE_DATA = 109
        const val VALID_USER_NAME = 1
        const val SESSION_TIMEOUT = 2
        const val CONTACT_PERMISSION_DETAILS = 3
        const val CAMERA_PERMISSION_DETAILS = 4
        const val GALLERY_PERMISSION_DETAILS = 5
        const val SCOPED_GALLERY_PERMISSION_DETAILS = 6
    }
}