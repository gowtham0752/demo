package com.fiserv.dps.mobile.sdk.bridge.zelleview

import android.util.Log
import com.fiserv.dps.mobile.sdk.BuildConfig
import com.fiserv.dps.mobile.sdk.bridge.model.BridgeConfig

/**
 * It provides the mechanism/way to create the url from the details received from parent app
 * Created by F5SP0MG on 16,June,2021
 */
class Zelle : BridgeConfig {

    constructor(applicationName: String? = "",
                baseURL: String,
                institutionId: String,
                product: String,
                ssoKey: String,
                //loaderData:Map<String, String>? = null,
                appData:Map<String, Map<String, String>>? = null,
                parameters: Map<String, String>? = null,){
        constructZelle( applicationName = applicationName,
                        baseURL = baseURL, institutionId = institutionId, product = product, ssoKey = ssoKey, PdData = appData, parameters = parameters)
    }

    constructor(
                baseURL: String,
                institutionId: String,
                product: String,
                ssoKey: String,
          //    loaderData:Map<String, String>? = null,
                appData:Map<String, Map<String, String>>? = null,
                parameters: Map<String, String>? = null,){
        constructZelle( applicationName = "",
            baseURL = baseURL, institutionId = institutionId, product = product, ssoKey = ssoKey, PdData = appData, parameters = parameters)
    }

    override var appName = ""
    override var url = ""
    override var preCacheContacts = false
    override var icon = ""
    override var text  = ""
    override var textColor = ""
    override var bgColor = ""
    override var appData: Map<String, Map<String, String>> = HashMap<String,Map<String, String>>()

    fun constructZelle(applicationName: String?, baseURL: String, institutionId: String,
                       product: String, ssoKey: String, PdData:Map<String, Map<String, String>>?, parameters: Map<String, String>? ){

        appName = applicationName!!

        /* if (loaderData != null){
             if (loaderData.containsKey("icon")){
                 this.icon = loaderData["icon"].toString()
             }else this.icon = ""
             if (loaderData.containsKey("text")){
                 this.text = loaderData["text"].toString()
             }else this.text = ""
             if (loaderData.containsKey("textColor")){
                 this.textColor = loaderData["textColor"].toString()
             }else this.textColor = ""
             if (loaderData.containsKey("bgColor")){
                 this.bgColor = loaderData["bgColor"].toString()
             }else this.bgColor = ""
         }*/

        //appData
        if(PdData == null || PdData!!.size <= 0){
            this.appData = HashMap<String,Map<String, String>>()
        }else{
            this.appData = PdData!!
        }
        //prepare the url using passed parameters
        url = baseURL
        // url = "https://dhayaaperumal.github.io/demo/index.html"
        url += "?INSTITUTION_ID=$institutionId&product=$product"
        url += "&container=mobile_sdk_android&version=${BuildConfig.VERSION_NAME}&KEY=$ssoKey"
        if(parameters != null)
            url += parameters!!.map { it.key + "=" + it.value }.joinToString("&", "&")

    }

}

