package com.fiserv.dps.mobile.sdk.bridge.model

data class DeviceInfo(
    var carrier:DeviceInfoModel? = null,
    var os:DeviceInfoModel? = null,
    var phone:DeviceInfoModel? = null,
    var ssid:String? = null
)
