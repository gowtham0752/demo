package com.fiserv.dps.mobile.sdk.handlers

import android.app.Activity
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment

/**
 * Handlers is the parent class of all the handlers, e.g. ContactHandlers, QRCodeHandlers
 * Created by F5SP0MG on 16,June,2021
 */
class Handlers(
    private val activity: Activity,
    private val fragment: BridgeFragment,
    private val evaluateJS: (String) -> Unit,
):
    DeviceInfoHandler by DeviceInfoHandlerImpl(fragment, evaluateJS),
    PermissionsHandler by PermissionsHandlerImpl(fragment, evaluateJS),
    ContactsHandler by ContactsHandlerImpl(fragment, evaluateJS),
    LocationHandler by LocationHandlerImpl(fragment, evaluateJS),
    QRCodeHandler by QRCodeHandlerImpl(fragment, evaluateJS),
    PhotosHandler by PhotosHandlerImpl(fragment, evaluateJS),
    ShareHandler by ShareHandlerImpl(fragment),
    PopupHandler by PopupHandlerImpl(fragment),
    SessionHandler by SessionHandlerImpl(fragment)




