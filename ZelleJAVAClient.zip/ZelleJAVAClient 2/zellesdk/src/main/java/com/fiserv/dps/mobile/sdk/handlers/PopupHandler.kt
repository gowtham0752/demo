package com.fiserv.dps.mobile.sdk.handlers

import android.webkit.JavascriptInterface
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.bridge.zelleview.BridgeView

/**
 * PopupHandler created to dismiss the pop from java script.
 * This interface will be called from java script
 * dismissPopup() function will be handle dismissing pop up.
 * Created by F5SP0MG on 21,June,2021
 */
interface PopupHandler {
    @JavascriptInterface fun dismissPopup()
}

/**
 * PopupHandler interface has been implemented in PopupHandlerImpl
 */
class PopupHandlerImpl(private val fragment: BridgeFragment): PopupHandler {
    @JavascriptInterface
    override fun dismissPopup() {
        if (fragment !is BridgeView) {
            (fragment as? BridgeFragment)?.dismiss()
        }
    }
}