package com.fiserv.dps.mobile.sdk.handlers

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil
import org.json.JSONObject

/**
 * PermissionsHandler created to verify the entire application permissions.
 * This interface will be called from java script.
 * checkPermissions() function used for check user permissions.
 * Created by F5SP0MG on 22,July,2021
 */
interface PermissionsHandler {
    @JavascriptInterface fun checkPermissions()
}

/**
 * PermissionsHandler interface has been implemented in PermissionsHandlerImpl
 */
class PermissionsHandlerImpl(private val fragment: BridgeFragment, private val evaluateJS: (String)->Unit): PermissionsHandler {

    private val jsonObject = JSONObject()

    @JavascriptInterface override fun checkPermissions() {

        jsonObject.put("contact", PermissionUtil.checkPermissionForReadContact(fragment.requireContext()))
        jsonObject.put("camera", PermissionUtil.checkPermissionForCamera(fragment.requireContext()))
        jsonObject.put("photo", PermissionUtil.checkPermissionForGallery(fragment.requireContext()))
        jsonObject.put("location", PermissionUtil.checkPermissionForLocation(fragment.requireContext()))
        callbackPermission(jsonObject)

    }

    /**
     * callbackPermission will be return the status of the permissions given by the user,
     * and it will shared to the WebView
     */
    private fun callbackPermission(permissions: JSONObject) {
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackPermissions({permission: '${permissions}'})")
        }, 1000)
    }
}