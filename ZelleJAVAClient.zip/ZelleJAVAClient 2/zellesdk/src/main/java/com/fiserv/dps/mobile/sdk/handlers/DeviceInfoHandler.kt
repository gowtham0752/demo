package com.fiserv.dps.mobile.sdk.handlers

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.utils.DeviceInfoUtil.getCarrier
import com.fiserv.dps.mobile.sdk.utils.DeviceInfoUtil.getOs
import com.fiserv.dps.mobile.sdk.utils.DeviceInfoUtil.getPhoneInfo
import com.fiserv.dps.mobile.sdk.utils.DeviceInfoUtil.getSSID
import com.fiserv.dps.mobile.sdk.utils.JsonFormatterUtil.toJson
import org.json.JSONObject

/**
 * DeviceInfoHandler created to get device information
 * this interface will be called from java script
 * getDeviceInfo() function will be handle to get device information
 * Created by F6W0W4F on 10/22/2021
 */
interface DeviceInfoHandler {
    @JavascriptInterface
    fun getDeviceInfo()
}

/**
 * DeviceInfoHandler interface has been implemented in DeviceInfoHandlerImpl
 */
class DeviceInfoHandlerImpl(private val fragment: BridgeFragment,
                            private val evaluateJS: (String) -> Unit):DeviceInfoHandler{
    /**
     * This method will collect device information's and send the details to UI
     */
    override fun getDeviceInfo() {
        val jsonObject = JSONObject()
        jsonObject.put("carrier" , toJson(getCarrier(fragment.requireContext())))
        jsonObject.put("os" , toJson(getOs()))
        jsonObject.put("phone", toJson(getPhoneInfo(fragment.requireContext())))
        jsonObject.put("ssid",  getSSID(fragment.requireContext()))
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackDeviceInfo({deviceInfo: '${jsonObject}'})")
        }, 1000)
    }

}