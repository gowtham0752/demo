package com.fiserv.dps.mobile.sdk.handlers

import android.Manifest
import android.content.Context.LOCATION_SERVICE
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_LOCATION_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_LOCATION
import com.fiserv.dps.mobile.sdk.utils.PermissionUtil
import org.json.JSONObject

/**
 * LocationHandler created to get user location
 * this interface will be called from java script
 * getLocation() function will be handle to get user location
 * Created by F6W0W4F on 20,July,2021
 */
interface LocationHandler {
    @JavascriptInterface fun getLocation()
}

/**
 * LocationHandler interface has been implemented in LocationHandlerImpl
 */
class LocationHandlerImpl(private val fragment: BridgeFragment, private val evaluateJS: (String)->Unit): LocationHandler, LocationListener {

    private var locationManager: LocationManager? = null

    /**
     * gpsSettingsActivityResultLauncher will handle the gps permission result from settings
     */
    private val gpsSettingsActivityResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            locationManager()
        }
    }

    /**
     * This locationActivityResultForPermission will handle the permission result callbacks
     */
    private val locationActivityResultForPermission = fragment.registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {

        if (PermissionUtil.checkPermissionForLocation(fragment.requireContext())){
            fragment.setThreshold(THRESHOLD_LIMIT_LOCATION)
            if (PermissionUtil.checkPermissionForGPS(locationManager!!, fragment, gpsSettingsActivityResultLauncher)){
                locationManager()
            }
        }else{
            PermissionUtil.checkUserRequestedDoNotAskAgainLocation(fragment,
                REQUEST_LOCATION_PERMISSION_SETTINGS, locationSettingsActivityResultLauncher)
        }
    }

    /**
     * locationSettingsActivityResultLauncher will handle the location permission result from settings
     */
    private val locationSettingsActivityResultLauncher = fragment.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (PermissionUtil.checkPermissionForLocation(fragment.requireContext())){
            if (PermissionUtil.checkPermissionForGPS(locationManager!!, fragment, gpsSettingsActivityResultLauncher)){
                locationManager()
            }
        }
    }

    /**
     * getLocation function will be handle to get location from native OS
     */
    @JavascriptInterface override fun getLocation() {

        locationManager = fragment.requireContext().getSystemService(LOCATION_SERVICE) as LocationManager

        if(PermissionUtil.checkPermissionForLocation(fragment.requireContext())){
            if (PermissionUtil.checkPermissionForGPS(locationManager!!, fragment, gpsSettingsActivityResultLauncher)){
                locationManager()
            }
        }else{
            locationActivityResultForPermission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
        }
    }

    /**
     *locationManager() requesting location update from location listener & checking permission  to access location from native OS
     */
    private fun locationManager(){
        if (ActivityCompat.checkSelfPermission(
                fragment.requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                fragment.requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        locationManager!!.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0f, this)
    }

    /**
     * This method will called when location is getting updated
     */
    override fun onLocationChanged(location: Location) {
        val jo = JSONObject()
        jo.put("latitude", location.latitude)
        jo.put("longitude", location.longitude)
        locationManager!!.removeUpdates(this)
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackLocation({location: '${jo}'})")
        }, 1000)
    }

    override fun onProviderDisabled(provider: String) {
        super.onProviderDisabled(provider)
    }

    override fun onProviderEnabled(provider: String) {
        super.onProviderEnabled(provider)
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        super.onStatusChanged(provider, status, extras)
    }
}