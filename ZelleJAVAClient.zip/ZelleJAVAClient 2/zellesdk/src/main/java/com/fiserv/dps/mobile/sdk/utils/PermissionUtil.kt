package com.fiserv.dps.mobile.sdk.utils

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CAMERA_DENY_MESSAGE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CAMERA_PERMISSION_DETAILS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CAMERA_PERMISSION_MESSAGE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CAMERA_PERMISSION_TITLE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CONTACT_DENY_MESSAGE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CONTACT_PERMISSION_DETAILS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CONTACT_PERMISSION_MESSAGE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.CONTACT_PERMISSION_TITLE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.ENABLE_GPS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.GALLERY_DENY_MESSAGE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.GALLERY_PERMISSION_DETAILS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.GALLERY_PERMISSION_MESSAGE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.GALLERY_PERMISSION_TITLE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.LOCATION_DENY_MESSAGE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.MEDIA_DENY_MESSAGE
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_CAMERA_FOR_PHOTO_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_LOCATION_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_ALL_CONTACT_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_CONTACT_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_GALLERY_FOR_PHOTO_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_QR_CAMERA_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_QR_GALLERY_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.REQUEST_READ_QR_MEDIA_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.SCOPED_GALLERY_PERMISSION_DETAILS
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.SESSION_TIMEOUT
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_CAMERA
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_CONTACT
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_GALLERY
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_LOCATION
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.THRESHOLD_LIMIT_MEDIA
import com.fiserv.dps.mobile.sdk.utils.Constants.Companion.ZELLE_TRADEMARK
import org.json.JSONObject

/**
 * PermissionUtil helps to validate all the application permissions
 * Created by F5SP0MG on 22,June,2021
 */
object PermissionUtil {

    /**
     * checkPermissionForReadContact check to read contact permission
     * @return boolean value
     */
    fun checkPermissionForReadContact(context: Context): Boolean {
        return (ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED)
    }
    /**
     * checkUserRequestedDoNotAskAgainContact will check the threshold limit, if it is ture then
     * alertDialogue will be initiated
     */
    fun checkUserRequestedDoNotAskAgainContact(fragment: BridgeFragment, code: Int, activityResultLauncher: ActivityResultLauncher<Intent>) {
        val rationalFlagReadContact =
            fragment.shouldShowRequestPermissionRationale(Manifest.permission.READ_CONTACTS)

        if (!rationalFlagReadContact) {
            val threshold = ThresholdLimitPreference.getLimit(
                fragment.requireContext(),
                THRESHOLD_LIMIT_CONTACT
            )

            if (threshold.isNotEmpty()) {
                if (threshold == "true") {
                    alertDialogue(
                        fragment,
                        fragment.config.appName,
                        CONTACT_DENY_MESSAGE,
                        positiveButton = "Settings",
                        negativeButton = "Deny",
                        code = code,
                        activityResultLauncher = activityResultLauncher
                    )
                } else {
                    ThresholdLimitPreference.save(
                        THRESHOLD_LIMIT_CONTACT,
                        "true",
                        fragment.requireContext()
                    )
                }
            } else {
                ThresholdLimitPreference.save(
                    THRESHOLD_LIMIT_CONTACT,
                    "true",
                    fragment.requireContext()
                )
            }
        }
    }

    /**
     * checkPermissionForCamera check the storage permission
     * @return boolean value
     */
    fun checkPermissionForCamera(context: Context): Boolean {
        return (ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED)
    }

    /**
     * checkUserRequestedDoNotAskAgainCamera will check the threshold limit, if it is ture then
     * alertDialogue will be initiated
     */
    fun checkUserRequestedDoNotAskAgainCamera(fragment: BridgeFragment, code: Int, activityResultLauncher: ActivityResultLauncher<Intent>) {
        val rationalFlagReadCamera =
            fragment.shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)

        if (!rationalFlagReadCamera) {
            val threshold = ThresholdLimitPreference.getLimit(
                fragment.requireContext(),
                THRESHOLD_LIMIT_CAMERA
            )

            if (threshold.isNotEmpty()) {
                if (threshold == "true") {
                    alertDialogue(
                        fragment,
                        fragment.config.appName,
                        CAMERA_DENY_MESSAGE,
                        positiveButton = "Settings",
                        negativeButton = "Deny",
                        code = code,
                        activityResultLauncher = activityResultLauncher
                    )
                } else {
                    ThresholdLimitPreference.save(
                        THRESHOLD_LIMIT_CAMERA,
                        "true",
                        fragment.requireContext()
                    )
                }
            } else {
                ThresholdLimitPreference.save(
                    THRESHOLD_LIMIT_CAMERA,
                    "true",
                    fragment.requireContext()
                )
            }
        }
    }

    /**
     * checkPermissionForGallery check the storage permission
     * @return boolean value
     */
    fun checkPermissionForGallery(context: Context): Boolean {
        return (ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED)
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    fun checkPermissionForMedia(context: Context): Boolean {
        return (ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_MEDIA_LOCATION
        ) == PackageManager.PERMISSION_GRANTED)
    }

    /**
     * checkUserRequestedDoNotAskAgainGallery will check the threshold limit, if it is ture then
     * alertDialogue will be initiated
     */
    fun checkUserRequestedDoNotAskAgainGallery(
        fragment: BridgeFragment,
        code: Int,
        activityResultLauncher: ActivityResultLauncher<Intent>
    ) {
        val rationalFlagReadGallery =
            fragment.shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)

        if (!rationalFlagReadGallery) {
            val threshold = ThresholdLimitPreference.getLimit(
                fragment.requireContext(),
                THRESHOLD_LIMIT_GALLERY
            )
            if (threshold.isNotEmpty()) {
                if (threshold.equals("false", true)) {
                    ThresholdLimitPreference.save(
                        THRESHOLD_LIMIT_GALLERY,
                        "true",
                        fragment.requireContext()
                    )
                } else {
                    alertDialogue(
                        fragment = fragment,
                        title = fragment.config.appName,
                        message = GALLERY_DENY_MESSAGE,
                        positiveButton = "Settings",
                        negativeButton = "Deny",
                        code = code,
                        activityResultLauncher = activityResultLauncher
                    )
                }
            } else {
                ThresholdLimitPreference.save(
                    THRESHOLD_LIMIT_GALLERY,
                    "true",
                    fragment.requireContext()
                )
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    fun checkUserRequestedDoNotAskAgainMedia(
        fragment: BridgeFragment,
        code: Int,
        activityResultLauncher: ActivityResultLauncher<Intent>
    ) {
        val rationalFlagReadMedia =
            fragment.shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_MEDIA_LOCATION)

        if (!rationalFlagReadMedia) {
            val threshold = ThresholdLimitPreference.getLimit(
                fragment.requireContext(),
                THRESHOLD_LIMIT_MEDIA
            )
            if (threshold.isNotEmpty()) {
                if (threshold.equals("false", true)) {
                    ThresholdLimitPreference.save(
                        THRESHOLD_LIMIT_MEDIA,
                        "true",
                        fragment.requireContext()
                    )
                } else {
                    alertDialogue(
                        fragment = fragment,
                        title = fragment.config.appName,
                        message = MEDIA_DENY_MESSAGE,
                        positiveButton = "Settings",
                        negativeButton = "Deny",
                        code = code,
                        activityResultLauncher = activityResultLauncher
                    )
                }
            } else {
                ThresholdLimitPreference.save(
                    THRESHOLD_LIMIT_MEDIA,
                    "true",
                    fragment.requireContext()
                )
            }
        }
    }

    /**
     * checkPermissionForLocation check the location permission
     * @return boolean value
     */
    fun checkPermissionForLocation(context: Context): Boolean {
        return (ContextCompat.checkSelfPermission(context,
            Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }

    /**
     * checkUserRequestedDoNotAskAgainLocation will check the threshold limit, if it is ture then
     * alertDialogue will be initiated
     */
    fun checkUserRequestedDoNotAskAgainLocation(
        fragment: BridgeFragment,
        code: Int,
        activityResultLauncher: ActivityResultLauncher<Intent>
    ) {
        val rationalFlagCourseLocation =
            fragment.shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION)
        val rationalFlagFineLocation =
            fragment.shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)

        if (!rationalFlagCourseLocation || !rationalFlagFineLocation) {
            val threshold = ThresholdLimitPreference.getLimit(
                fragment.requireContext(),
                THRESHOLD_LIMIT_LOCATION
            )
            if (threshold.isNotEmpty()) {
                if (threshold.equals("false", true)) {
                    ThresholdLimitPreference.save(
                        THRESHOLD_LIMIT_LOCATION,
                        "true",
                        fragment.requireContext()
                    )
                } else {
                    alertDialogue(
                        fragment = fragment,
                        title = fragment.config.appName,
                        message = LOCATION_DENY_MESSAGE,
                        positiveButton = "Settings",
                        negativeButton = "Deny",
                        code = code,
                        activityResultLauncher = activityResultLauncher
                    )
                }
            } else {
                ThresholdLimitPreference.save(
                    THRESHOLD_LIMIT_LOCATION,
                    "true",
                    fragment.requireContext()
                )
            }
        }
    }

    /**
     *checkPermissionForGPS will check GPS permission and return true/false.  If GPS is not enabled it will request
     * alert view
     */
    fun checkPermissionForGPS(locationManager: LocationManager, fragment: BridgeFragment, activityResultLauncher: ActivityResultLauncher<Intent>): Boolean{
        return if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            true
        }else{
            alertDialogue(
                fragment =  fragment,
                title = "Enable GPS",
                message = Constants.GPS_DENY_MESSAGE,
                negativeButton = "Cancel",
                code = ENABLE_GPS,
                activityResultLauncher = activityResultLauncher
            )
            false
        }
    }

    /**
     * alertDialogue will show based on the action to be needed
     * @param activity
     * @param title
     * @param message
     * @param positiveButton
     */
    fun alertDialogue(activity: Activity, title: String, message: String, positiveButton: String) {
        val builder = AlertDialog.Builder(activity)
        builder.setMessage(message)
        if (title.isNotEmpty()) {
            builder.setTitle(title)
        }
        builder.setPositiveButton(positiveButton) { _, _ ->
            builder.context
        }
        builder.create().show()
    }

    /**
     * alertDialogue will show based on the action to be needed
     * @param fragment
     * @param title
     * @param message
     * @param positiveButton
     * @param negativeButton
     * @param code
     */
    fun alertDialogue(
        fragment: BridgeFragment,
        title: String? = "",
        message: String,
        positiveButton: String? = "Ok",
        negativeButton: String? = "",
        code: Int,
        activityResultLauncher: ActivityResultLauncher<Intent>? = null,
        pdARL : ActivityResultLauncher<String>? = null
    ) {
        val builder = AlertDialog.Builder(fragment.requireContext())
        //alert title
        if (title!!.isNotEmpty() && title != "null") {
            builder.setTitle(title)
        }else if (code == CONTACT_PERMISSION_DETAILS){
            builder.setTitle(CONTACT_PERMISSION_TITLE)
        }
        else if (code == CAMERA_PERMISSION_DETAILS){
            builder.setTitle(CAMERA_PERMISSION_TITLE)
        }
        else if (code == GALLERY_PERMISSION_DETAILS || code == SCOPED_GALLERY_PERMISSION_DETAILS){
            builder.setTitle(GALLERY_PERMISSION_TITLE)
        }
        //alert message
        if (message.isNotEmpty() && message != "null"){
            builder.setMessage(message)
        }else if (code == CONTACT_PERMISSION_DETAILS){
            builder.setMessage(HtmlCompat.fromHtml(CONTACT_PERMISSION_MESSAGE+"<sup><small>$ZELLE_TRADEMARK</small></sup>.", HtmlCompat.FROM_HTML_MODE_COMPACT))
        }
        else if (code == CAMERA_PERMISSION_DETAILS){
            builder.setMessage(HtmlCompat.fromHtml(CAMERA_PERMISSION_MESSAGE+"<sup><small>$ZELLE_TRADEMARK</small></sup>.", HtmlCompat.FROM_HTML_MODE_COMPACT))
        }
        else if (code == GALLERY_PERMISSION_DETAILS || code == SCOPED_GALLERY_PERMISSION_DETAILS){
            builder.setMessage(HtmlCompat.fromHtml(GALLERY_PERMISSION_MESSAGE+"<sup><small>$ZELLE_TRADEMARK</small></sup>.", HtmlCompat.FROM_HTML_MODE_COMPACT))
        }
        builder.setPositiveButton(positiveButton) { _, _ ->
            when (code) {
                REQUEST_READ_CONTACT_PERMISSION_SETTINGS -> {
                    openDeviceSettings(fragment, activityResultLauncher!!)
                }
                REQUEST_READ_ALL_CONTACT_PERMISSION_SETTINGS -> {
                    openDeviceSettings(fragment, activityResultLauncher!!)
                }
                REQUEST_READ_QR_CAMERA_PERMISSION_SETTINGS -> {
                    openDeviceSettings(fragment, activityResultLauncher!!)
                }
                REQUEST_READ_QR_GALLERY_PERMISSION_SETTINGS -> {
                    openDeviceSettings(fragment, activityResultLauncher!!)
                }
                REQUEST_READ_QR_MEDIA_PERMISSION_SETTINGS -> {
                    openDeviceSettings(fragment, activityResultLauncher!!)
                }
                REQUEST_CAMERA_FOR_PHOTO_SETTINGS -> {
                    openDeviceSettings(fragment, activityResultLauncher!!)
                }
                REQUEST_READ_GALLERY_FOR_PHOTO_SETTINGS -> {
                    openDeviceSettings(fragment, activityResultLauncher!!)
                }
                ENABLE_GPS -> {
                    enableGPS(activityResultLauncher!!)
                }
                REQUEST_LOCATION_PERMISSION_SETTINGS -> {
                    openDeviceSettings(fragment, activityResultLauncher!!)
                }
                CONTACT_PERMISSION_DETAILS -> {
                    pdARL!!.launch(Manifest.permission.READ_CONTACTS)
                }
                CAMERA_PERMISSION_DETAILS -> {
                    pdARL!!.launch(Manifest.permission.CAMERA)
                }
                GALLERY_PERMISSION_DETAILS -> {
                    pdARL!!.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
                SCOPED_GALLERY_PERMISSION_DETAILS -> {
                    pdARL!!.launch(Manifest.permission.ACCESS_MEDIA_LOCATION)
                }
            }
        }
        builder.setNegativeButton(negativeButton) { _, _ ->
            if (code == SESSION_TIMEOUT) {
                //fragment.activity?.finish()
                fragment.requireActivity().supportFragmentManager.beginTransaction()?.remove(fragment)?.commit()
            } else {
                builder.context
            }
        }
        builder.create().show()
    }

    private fun enableGPS(activityResultLauncher: ActivityResultLauncher<Intent>) {
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        activityResultLauncher.launch(intent)
    }

    /**
     * openDeviceSettings() will open the device setting
     */
    private fun openDeviceSettings(
        fragment: BridgeFragment,
        activityResultLauncher: ActivityResultLauncher<Intent>) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        val uri = Uri.fromParts("package", fragment.requireContext().packageName, null)
        intent.data = uri
        activityResultLauncher.launch(intent)
    }

    /**
     * isNetworkAvailable() checks if mobile data is connected or not
     * It will check Mobile data, Wi-Fi, Ethernet connections
     */
    fun isNetworkAvailable(context: Context?): Boolean {
        if (context == null) return false
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val capabilities = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
        } else {
           return true
        }
        if (capabilities != null) {
            when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                    return true
                }
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                    return true
                }
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> {
                    return true
                }
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> {
                    return true
                }
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI_AWARE) -> {
                    return true
                }
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> {
                    return true
                }
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_LOWPAN) -> {
                    return true
                }

            }
        }
        return false
    }

    /**
     * isLocationEnabled() checks if mobile location is turned On or not
     */
    fun isLocationEnabled(context: Context):Boolean{
        val locationManager  = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER)
    }

     fun callbackPermission(fragment: BridgeFragment, evaluateJS: (String) -> Unit, ) {
        val jsonObject = JSONObject()
        jsonObject.put("contact", PermissionUtil.checkPermissionForReadContact(fragment.requireContext()))
        jsonObject.put("camera", PermissionUtil.checkPermissionForCamera(fragment.requireContext()))
        jsonObject.put("photo", PermissionUtil.checkPermissionForGallery(fragment.requireContext()))
        jsonObject.put("location", PermissionUtil.checkPermissionForLocation(fragment.requireContext()))
         Log.d("Check Permission","------------>${jsonObject.toString()}")
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackPermissions({permission: '${jsonObject}'})")
        }, 1000)
    }
}