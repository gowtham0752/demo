package com.taxi.zellejavaclient;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.taxi.zellejavaclient.R;
import com.taxi.zellejavaclient.ZelleBridgeViewWrapper;


public class ZelleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ZelleBridgeViewWrapper zelleBridgeViewWrapper = new ZelleBridgeViewWrapper();
        setContentView(zelleBridgeViewWrapper.loadZelleBridgeView(getApplicationContext()));
    }
}