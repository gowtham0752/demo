package com.taxi.zellejavaclient;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.fiserv.dps.mobile.sdk.bridge.model.Bridge;
import com.fiserv.dps.mobile.sdk.bridge.zelleview.BridgeView;
import com.fiserv.dps.mobile.sdk.bridge.zelleview.Zelle;
import com.konylabs.android.KonyMain;

import java.util.HashMap;
import java.util.Map;

public class ZelleBridgeViewWrapper {
    LinearLayout linearLayout;
    private static final int CONTENT_VIEW_ID = 10101010;

    @SuppressLint("SetJavaScriptEnabled")
    public LinearLayout loadZelleBridgeView(Context applicationContext) {


//        Context konyAppContext = KonyMain.getAppContext();
//        KonyMain konyactContext = KonyMain.getActContext();
//        KonyMain konyactivityContext = KonyMain.getActivityContext();
//
//        Log.d("konyAppContect", "-----------------" + konyAppContext);
//        Log.d("konyactContext", "-----------------" + konyactContext);
//        Log.d("konyactivityContext", "-----------------" + konyactivityContext);

        this.linearLayout = new LinearLayout(applicationContext);
        this.linearLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        this.linearLayout.setOrientation(LinearLayout.VERTICAL);
        this.linearLayout.setPadding(100, 0, 0, 0);
        LinearLayout.LayoutParams rightGravityParams = new LinearLayout.LayoutParams(-1, -1);

        HashMap<String, String> params = new HashMap<String, String>();
        params.put("key1", "value1");
        params.put("key2", "value2");
        params.put("key3", "value3");

        Map<String, String> pdContact = new HashMap<String, String>();
        pdContact.put("title", "We would like to access your phone contacts"); //prominent disclosure title
        pdContact.put("message", "We only sync phone numbers and email addresses from your contact list to help you add and pay a new recipient in Zelle®"); //prominent disclosure message

        Map<String, String> pdCamera = new HashMap<String, String>();
        pdCamera.put("title", "We would like to access your camera"); //prominent disclosure title
        pdCamera.put("message", "We only access your camera to help you add and pay a new recipient in Zelle®"); //prominent disclosure message

        Map<String, String> pdPhotos = new HashMap<String, String>();
        pdPhotos.put("title", "We would like to access your photos"); //prominent disclosure title
        pdPhotos.put("message", "We only access your photos to help you add and pay a new recipient in Zelle®"); //prominent disclosure message

        Map<String, Map<String, String>> appData = new HashMap<String, Map<String, String>>();
        appData.put("pd_contact", pdContact);
        appData.put("pd_camera", pdCamera);
        appData.put("pd_gallery", pdPhotos);


        Zelle zelle = new Zelle(
                "Demo Bank", //applicationName (Optional)
                "https://www.google.com/", //baseURL
                "mob", //institutionId
                "zelle", //product
                "iehiif", // ssoKey
                null,
                null
        );
        Bridge bridge = new Bridge(applicationContext, zelle);
        zelle.setPreCacheContacts(true);
        BridgeView bridgeView = bridge.view();

//        Log.d("TAG bridgeView", "" + bridgeView);
//        Log.d("TAG getDialog", "" + bridgeView.getDialog());
//        Log.d("TAG getView", "" + bridgeView.getView());

//        Toast.makeText(applicationContext, " "+bridgeView.getView(), Toast.LENGTH_LONG).show();

       MyDialogFragment dialogFragment = new MyDialogFragment(applicationContext, bridgeView);

        AlertDialog dialog = (AlertDialog) dialogFragment.onCreateDialog(null);
        dialog.create();

        Log.d("BridgeView dialog 1", "" + dialog.getWindow().getDecorView());

//        View toplayout = ((Activity) applicationContext).getWindow().getDecorView().getRootView();
     //   View rootView = ((Activity) applicationContext).getWindow().getDecorView().findViewById(android.R.id.content);
        //        Activity host = (Activity) rootView.getContext();

//        FragmentManager fragmentManager = ((FragmentActivity) applicationContext).getSupportFragmentManager();
//        FragmentTransaction fragTransaction = fragmentManager.beginTransaction();
//        fragTransaction.add(CONTENT_VIEW_ID, bridgeView).commit();

        FrameLayout FL = new FrameLayout(applicationContext);
        FL.setBackgroundColor(Color.parseColor("#00ff00"));
        FL.setLayoutParams(rightGravityParams);
       // FL.setId(CONTENT_VIEW_ID);
      //  FL.addView(bridgeView.getDialog().);

        FL.addView(dialog.getWindow().getDecorView());
        this.linearLayout.addView(FL);
        return this.linearLayout;
    }

}

class MyDialogFragment extends DialogFragment {
   Context context;
   BridgeView bridgeView;
   String MyTAG = "ZelleBridge";

   MyDialogFragment(Context context, BridgeView view){
       this.context = context;
       this.bridgeView = view;
   }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LinearLayout linearLayout;
        linearLayout = new LinearLayout(context);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        linearLayout.addView((bridgeView.getView()));

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
       // View alertView = LayoutInflater.from(context).inflate(R.layout.activity_main, null);
        builder.setView(linearLayout);
//        builder.setTitle("Kony");
//        builder.setMessage("Testing");
//        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialogInterface, int i) {
//                Log.d(MyTAG, "Positive Button");
//            }
//        });
//        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialogInterface, int i) {
//                Log.d(MyTAG, "Negative Button");
//            }
//        });

        return builder.create();
    }
}


