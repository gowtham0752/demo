package com.taxi.zellejavaclient;

public class Constants {
    static String image = "";
}
