package com.taxi.zellejavaclient;

import android.app.Application;



public class ZelleStart extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        //Sherlock.init(this);
    }
}
