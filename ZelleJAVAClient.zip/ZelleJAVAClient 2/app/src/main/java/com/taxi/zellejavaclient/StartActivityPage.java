package com.taxi.zellejavaclient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.HtmlCompat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class StartActivityPage extends AppCompatActivity {
Button button;
TextView zelle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        zelle = findViewById(R.id.zelle);
        button = findViewById(R.id.click);
        Uri uri = getIntent().getData();
        if(uri != null){
            Toast.makeText(this, uri.toString(), Toast.LENGTH_SHORT).show();
        }
//
        zelle.setText(HtmlCompat.fromHtml("Zelle<sup><small>\u00AE</small></sup>.", HtmlCompat.FROM_HTML_MODE_COMPACT));
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //throw new RuntimeException("Crash");
                startActivity(new Intent(StartActivityPage.this, MainActivity.class));
            }
        });
    }
}