package com.fiserv.dps.mobile.sdk

import com.fiserv.dps.mobile.sdk.bridge.model.Contact
import org.json.JSONException
import org.json.JSONObject
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class ContactObjectTest {

    @Test
    fun contactObject(){
        var contact = Contact()
        contact.name = "gg"
      //  contact.email = "gmail"
       // contact.phone = "123"
        var json: JSONObject? = null
        try {
            json = JSONObject(contact.toString())
          //  Log.d("contact","--------------->${json}")
          //  assert(json.get("name").equals("gg"))
        }catch (e: JSONException){

        }
    }
}