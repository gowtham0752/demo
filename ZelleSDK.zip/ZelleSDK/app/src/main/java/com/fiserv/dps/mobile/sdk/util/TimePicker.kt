package com.fiserv.dps.mobile.sdk.util

import android.util.Log
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

object TimePicker {
    val format = SimpleDateFormat("MM/dd/yyyy HH:mm:ss")
    var starttime = Date()
    var endtime = Date()

    fun getCurrentTime(): String {
        val today = Date()
        val dateToStr: String = format.format(today)
        return dateToStr
    }

    fun getExtraHourwithTimeGiven(hour:Int, time:String): String {
        var today = Date()
        today = format.parse(time)
        val c = Calendar.getInstance()
        c.time = today
        c.add(Calendar.HOUR, hour)
        today = c.getTime()
        val dateToStr: String = format.format(today)
        return dateToStr
    }

    fun timeDifferenceInHour(startTime:String, endTime:String): Array<Long?> {
        val time = arrayOfNulls<Long>(2)
        try {
            starttime = format.parse(startTime)
            endtime = format.parse(endTime)

        } catch (e: ParseException) {
            e.printStackTrace()
        }
        val difference: Long = starttime.getTime() - endtime.getTime()
        val days: Long = (difference / (1000 * 60 * 60 * 24))
        var hours: Long = ((difference - 1000 * 60 * 60 * 24 * days) / (1000 * 60 * 60))
        var min = (difference - 1000 * 60 * 60 * 24 * days - 1000 * 60 * 60 * hours).toInt() / (1000 * 60).toLong()
        val sec = (difference - 1000 * 60 * 60 * 24 * days - 1000 * 60 * 60 * hours - 1000 * 60 * min).toInt() / 1000.toLong()
        if(hours < 0){
            hours = 0
        }
        if (min < 0){
            min = 0
        }
        time[0] = hours
        time[1] = min
        Log.d("Minute","-----------------${min}")
        return time
    }
}