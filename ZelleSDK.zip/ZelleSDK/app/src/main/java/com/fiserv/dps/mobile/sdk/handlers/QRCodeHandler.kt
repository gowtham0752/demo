package com.fiserv.dps.mobile.sdk.handlers

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import androidx.fragment.app.Fragment
import com.fiserv.dps.mobile.sdk.Activity.ScanQRActivity
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.util.PermissionUtil
import com.google.zxing.integration.android.IntentIntegrator


interface QRCodeHandler {

    @JavascriptInterface fun scanQRCode()
    @JavascriptInterface fun selectQRCodeFromPhotos()
}

class QRCodeHandlerImpl(private val fragment: Fragment, private val evaluateJS: (String)->Unit): QRCodeHandler {
    @JavascriptInterface
    override fun scanQRCode() {
        if(PermissionUtil.checkPermissionForCamera(fragment.requireContext())){
            openQR()
        }else{
            PermissionUtil.requestPermissionForCamera(fragment = fragment)
        }
//

//
    }

    @JavascriptInterface override fun selectQRCodeFromPhotos() {

        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackQRCode({code: '${"selectQRCodeFromPhotos not implemented"}'})")
        }, 3000)

      //  Toast.makeText(fragment.context, "selectQRCodeFromPhotos Called", Toast.LENGTH_LONG).show()
    }


    fun openQR(){
//            Log.d("QR","---------------->QR Started")
//            val integrator = IntentIntegrator.forSupportFragment(fragment)
//            Log.d("QR","---------------->QR Initialized")
//            //integrator.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES)
//            integrator.setPrompt("Scan a barcode")
//            integrator.setCameraId(0) // Use a specific camera of the device
//            integrator.setBeepEnabled(false)
//            integrator.setOrientationLocked(true)
//            integrator.setBarcodeImageEnabled(true)
//            integrator.setTimeout(8000)
//            integrator.addExtra("SCAN_WIDTH", 100);
//            integrator.addExtra("SCAN_HEIGHT", 100);
//            integrator.initiateScan()
        var navs = Intent(fragment.requireActivity() , ScanQRActivity::class.java)
        fragment.requireActivity().startActivity(navs)

    }



}