package com.fiserv.dps.mobile.sdk.Activity

import android.content.Intent
import android.database.Cursor
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import com.fiserv.dps.mobile.sdk.R
import com.fiserv.dps.mobile.sdk.bridge.model.Contact
import com.fiserv.dps.mobile.sdk.bridge.model.Contacts
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.CONTACT_DETAILS
import com.fiserv.dps.mobile.sdk.util.ContactUtil
import com.fiserv.dps.mobile.sdk.util.Validator.validateEmail
import com.fiserv.dps.mobile.sdk.util.Validator.validateMobileNumber
import com.fiserv.dps.mobile.sdk.util.Validator.validateName
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_contact_detail.*
import java.util.*
import com.fiserv.dps.mobile.sdk.Adapters.ContactDetailsListAdapter
import com.fiserv.dps.mobile.sdk.util.CircleImage.circleBitmap
import com.fiserv.dps.mobile.sdk.util.CircleImage.generateCircleBitmap


class ContactDetailActivity : AppCompatActivity() {
    lateinit var contactDetailsAdapter: ContactDetailsListAdapter
    lateinit var contact:Contact

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar!!.hide()
        setContentView(R.layout.activity_contact_detail)
        init()
        val contact = intent.data
        if(contact != null){
            getContactData(contact)
        }
    }

    
    fun init(){
        back_press.setOnClickListener {
           sendResultBack(RESULT_CANCELED , null)

        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        sendResultBack(RESULT_CANCELED, null)

    }

     fun setRecyclerview(data: ArrayList<String>) {
         contactDetailsAdapter = ContactDetailsListAdapter(this, data , object :
             ContactDetailsListAdapter.ContactsClick{
             override fun getContact(value: String) {
                 var number: String? = null
                 var email:String? = null
                 if(validateMobileNumber(value)){
                     number = value.filter { it.isDigit() }
                 }else if(validateEmail(value)){
                     email = value
                 }
                 if(validateName(contact.name!!)){
                     val result = Contacts(name = contact.name , phoneNumber = number , email = email)
                     sendResultBack(RESULT_OK , result)
                     Log.d("Result","-------------------------->${Gson().toJson(result)}")

                 }
             }

         })
         rcv_contact_details.adapter = contactDetailsAdapter

//         contactDetailsAdapter = ContactDetailsAdapter(applicationContext,data,object : ContactDetailsAdapter.ContactsClick{
//            override fun getContact(value: String) {
//                var number: String? = null
//                var email:String? = null
//                if(validateMobileNumber(value)){
//                    number = value.filter { it.isDigit() }
//                }else if(validateEmail(value)){
//                    email = value
//                }
//                if(validateName(contact.name!!)){
//                    val result = Contacts(name = contact.name , phoneNumber = number , email = email)
//                    sendResultBack(RESULT_OK , result)
//                    Log.d("Result","-------------------------->${Gson().toJson(result)}")
//
//                }
//
//            }
//        })
//        rcv_contact_details.adapter = contactDetailsAdapter
//        rcv_contact_details.layoutManager = LinearLayoutManager(applicationContext)
    }

    fun getContactData(uriContact:Uri){
        val cursorID: Cursor = getContentResolver().query(
            uriContact, arrayOf(ContactsContract.Contacts._ID),
            null, null, null
        )!!
        if (cursorID.moveToFirst()) {
            contact = Contact()
            val contactID = cursorID.getString(cursorID.getColumnIndex(ContactsContract.Contacts._ID))
            contact.name = ContactUtil.getContactName(applicationContext, uriContact)
            contact.phone = ContactUtil.getContactNumber(applicationContext, contactID, false)!!
            contact.email = ContactUtil.getNameEmailDetails(applicationContext, contactID, false)!!
            contact.photoBitmap = ContactUtil.getContactPhoto(applicationContext, contactID)
            if(contact.photoBitmap != null){
                cv_contact_profile.setImageDrawable(circleBitmap(resources , contact.photoBitmap!!))
            }else{
             //   if(contact.name != null)

                cv_contact_profile.setImageDrawable(circleBitmap(resources ,generateCircleBitmap(applicationContext,70.0f,
                    contact.name!!.substring(0,1))!!))
            }
            tv_contact_name.text = contact.name
            val data = ArrayList<String>()
            data.addAll(contact.phone)
            data.addAll(contact.email)
            setRecyclerview(data)

        }
        cursorID.close()
    }


    fun sendResultBack(result: Int, contact: Contacts?){
        val returnIntent = Intent()
        if(contact != null){
            returnIntent.putExtra(CONTACT_DETAILS, Gson().toJson(contact))
        }
        setResult(result , returnIntent)
        finish()
    }

}