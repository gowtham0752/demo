package com.fiserv.dps.mobile.sdk.bridge.model

data class QrCode(
    var qrCode:String,
    var error: ErrorObject?
)
