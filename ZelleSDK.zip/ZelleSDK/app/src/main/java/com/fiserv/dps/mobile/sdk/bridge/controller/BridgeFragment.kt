package com.fiserv.dps.mobile.sdk.bridge.controller


import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Context
import android.content.Context.CONNECTIVITY_SERVICE
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.*
import android.view.View.GONE
import android.view.View.VISIBLE
import android.webkit.*
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.fiserv.dps.mobile.sdk.Activity.ContactDetailActivity
import com.fiserv.dps.mobile.sdk.BuildConfig
import com.fiserv.dps.mobile.sdk.R
import com.fiserv.dps.mobile.sdk.bridge.model.BridgeConfig
import com.fiserv.dps.mobile.sdk.bridge.model.Contacts
import com.fiserv.dps.mobile.sdk.bridge.model.QrModel
import com.fiserv.dps.mobile.sdk.bridge.view.BridgePopup
import com.fiserv.dps.mobile.sdk.handlers.ContactsHandlerImpl
import com.fiserv.dps.mobile.sdk.handlers.Handlers
import com.fiserv.dps.mobile.sdk.handlers.LocationHandlerImpl
import com.fiserv.dps.mobile.sdk.handlers.QRCodeHandlerImpl
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.CAMERA_DENY
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.CONTACT_DENY
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.CONTACT_DETAILS
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.ENABLE_GPS
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.INVALID_CONTACT_DETAIL
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.INVALID_QR_CODE
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.NO_DATA_FOUND
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_CAMERA_PERMISSION
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_CAMERA_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_READ_CONTACT_DETAILS_PERMISSION
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_READ_CONTACT_PERMISSION
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_READ_CONTACT_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.THRESHOLD_LIMIT_CAMERA
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.THRESHOLD_LIMIT_CONTACT
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.VALID_USER_NAME
import com.fiserv.dps.mobile.sdk.util.PermissionUtil
import com.fiserv.dps.mobile.sdk.util.QrUtils.checkQrCode
import com.fiserv.dps.mobile.sdk.util.ThresholdLimitPreference
import com.google.gson.Gson
import com.google.zxing.integration.android.IntentIntegrator
import kotlinx.android.synthetic.main.fragment_bridge_view.*




@SuppressLint("SetJavaScriptEnabled")
open class BridgeFragment: DialogFragment {
     var activity: Activity? = null
    lateinit var config: BridgeConfig

    constructor() : super()
    constructor( activity: Activity, config: BridgeConfig, popup: Boolean) {
       this.activity = activity
        this.config = config
      if(popup){
        dialog?.window?.apply {
            resources.displayMetrics.also {
                setLayout(it.widthPixels, (it.heightPixels * 0.8).toInt())
                setGravity(Gravity.BOTTOM)
            }
        }
        isCancelable = false
      }
    }

    private var uriContact: Uri? = null
    lateinit var contactID: String
    private val evaluateJS = { js: String -> webView.evaluateJavascript(js, null) }
    var sharedPreferences: SharedPreferences? = null


   fun loadUi(){

       if(activity != null) {
           if (webView != null) {
               sharedPreferences = activity!!.getSharedPreferences("zelle", Context.MODE_PRIVATE)
               webView.settings.javaScriptEnabled = true
               loader.visibility = VISIBLE
               webView.addJavascriptInterface(
                   Handlers(activity!!, this, evaluateJS), "FTKAndroidInterface"
               )
               webView.setWebChromeClient(object : WebChromeClient() {
                   override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                       return super.onJsAlert(view, url, message, result)
                   }
               })


               if (isNetworkAvailable(requireContext())) {
                   webView.loadUrl(config.url)

               } else {
                   Toast.makeText(requireContext(), "Network Not Available", Toast.LENGTH_SHORT).show()
               }
               webView.canGoBack()
               webView.setOnKeyListener(object : View.OnKeyListener {
                   override fun onKey(v: View?, keyCode: Int, event: KeyEvent?): Boolean {
                       if (keyCode == KeyEvent.KEYCODE_BACK
                           && event!!.action == MotionEvent.ACTION_UP
                           && webView.canGoBack()
                       ) {
                           webView.goBack()
                           return true
                       }
                       return false
                   }
               })
               webView.settings.loadWithOverviewMode = true
               webView.settings.useWideViewPort = true

               webView.webViewClient = object : WebViewClient() {
                   override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest?): Boolean {
                       view.loadUrl("javascript:clickFunction()")
                       loader.visibility = VISIBLE
                       return true;
                   }
                   override fun onPageFinished(view: WebView, url: String) {
                       loader.visibility = GONE
                   }
               }

               // webView.loadUrl("http://04c3bf301fce.ngrok.io/brandx/?institution_id=8888002#/&key=b998d4ac3b0373215474f15db2f66988")
           }else{
               Log.d("Bridge Fragment","--------------->webView Null")
           }
       }else{
         //  Toast.makeText(activity!!.applicationContext,"activity null", Toast.LENGTH_SHORT).show()
           setThreshold("false", THRESHOLD_LIMIT_CONTACT)

       }
   }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_bridge_view, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadUi()

    }

    fun isNetworkAvailable(context: Context?): Boolean {
        if (context == null) return false
        val connectivityManager = context.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val capabilities = connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
            if (capabilities != null) {
                when {
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                        return true
                    }
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                        return true
                    }
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> {
                        return true
                    }
                }
            }
        } else {
            val activeNetworkInfo = connectivityManager.activeNetworkInfo
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected) {
                return true
            }
        }
        return false
    }


    fun setThreshold(value:String, key:String){
        val threshold = ThresholdLimitPreference.getLimit(requireContext(), key)
        if(!threshold.isEmpty()){
                ThresholdLimitPreference.save(key, value, requireContext())
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents == null) {
                PermissionUtil.alertDialogue(this, NO_DATA_FOUND, "Ok", "", VALID_USER_NAME)
            } else {
//                if(checkQrCode(result.contents)){
                    callBackQR(result.contents)
//                }else{
//                    PermissionUtil.alertDialogue(this, INVALID_QR_CODE, "Ok", "", VALID_USER_NAME)
//                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
        if(requestCode == REQUEST_READ_CONTACT_PERMISSION) {
            if(data != null) {
                uriContact = data.getData()
                val intent = Intent(requireContext(), ContactDetailActivity::class.java)
                intent.data = data.data
                startActivityForResult(intent, REQUEST_READ_CONTACT_DETAILS_PERMISSION)
            }
        }
        else if (requestCode == REQUEST_READ_CONTACT_DETAILS_PERMISSION) {
            if (resultCode == Activity.RESULT_OK) {
              var contact = Gson().fromJson<Contacts>(data!!.getStringExtra(CONTACT_DETAILS), Contacts::class.java)
                if(contact.name != null && (contact.email != null || contact.phone != null)) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        evaluateJS("callbackOneContact({contact: '${Gson().toJson(contact)}'})")
                    }, 1000)
                }else{
                    PermissionUtil.alertDialogue(this, INVALID_CONTACT_DETAIL, "Ok", "", VALID_USER_NAME)

                }
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                callSingleContact()
            }
        }
       else if(requestCode == REQUEST_READ_CONTACT_PERMISSION_SETTINGS ) {
            callSingleContact()

        }
        else if(requestCode == REQUEST_CAMERA_PERMISSION_SETTINGS ) {
           openQR()

        }
        else if(requestCode == ENABLE_GPS ) {
            val locationHandler = LocationHandlerImpl(this, evaluateJS)
            locationHandler.locationManager()

        }

    }


    fun callBackQR(result : String){
        //var qr = QrCode(result, null)

        var qr  = QrModel()
        qr.user_value = result
        Log.d("QR", "------------------->${Gson().toJson(qr)}")
                Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackQRCode({code: '${Gson().toJson(qr)}'})")
        }, 1000)
    }



    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.size > 0) {
            if (requestCode == REQUEST_READ_CONTACT_PERMISSION) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    setThreshold("false", THRESHOLD_LIMIT_CONTACT)
                    callSingleContact()
                    Log.d("SingleContact", "-------------->Permission Granted")
                } else {
                    Log.d("SingleContact", "-------------->Permission Denied")
                    PermissionUtil.checkUserRequestedDontAskAgainContacts(this , CONTACT_DENY )
                }
            }else if (requestCode == REQUEST_CAMERA_PERMISSION) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    setThreshold("false", THRESHOLD_LIMIT_CAMERA)
                    openQR()
                    Log.d("QR Scan", "-------------->Permission Granted")
                } else if(grantResults[0] == PackageManager.PERMISSION_DENIED){
                    Log.d("QR Scan", "-------------->Permission Denied")
                    PermissionUtil.checkUserRequestedDontAskAgainCamera(this , CAMERA_DENY )
                }
            }
        }
    }

    fun callSingleContact(){
        if(PermissionUtil.checkPermissionForReadContact(this.requireContext())) {
            setThreshold("false", THRESHOLD_LIMIT_CONTACT)
            var contactHandler = ContactsHandlerImpl(this, evaluateJS)
            contactHandler.getSingleContact()
        }
    }

    fun openQR(){
        if(PermissionUtil.checkPermissionForCamera(this.requireContext())) {
            setThreshold("false", THRESHOLD_LIMIT_CAMERA)
            var contactHandler = QRCodeHandlerImpl(this, evaluateJS)
            contactHandler.openQR()
        }
    }

    private fun webViewGoBack() {
        webView.goBack()
    }
}