package com.fiserv.dps.mobile.sdk.util

import android.content.Context
import android.content.res.Resources
import android.graphics.*

import android.util.DisplayMetrics
import androidx.core.graphics.drawable.RoundedBitmapDrawable
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory
import java.lang.StringBuilder
import java.util.*


object CircleImage {

    fun generateCircleBitmap(context: Context, diameterDP: Float, text: String?): Bitmap? {
        val rnd = Random()
        val currentColor: Int = Color.argb(100, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
        val textColor = -0x1
        val metrics: DisplayMetrics = Resources.getSystem().getDisplayMetrics()
        val diameterPixels = diameterDP * (metrics.densityDpi / 160f)
        val radiusPixels = diameterPixels / 2

        // Create the bitmap
        val output = Bitmap.createBitmap(
            diameterPixels.toInt(), diameterPixels.toInt(),
            Bitmap.Config.ARGB_8888
        )

        // Create the canvas to draw on
        val canvas = Canvas(output)
        canvas.drawARGB(0, 0, 0, 0)

        // Draw the circle
        val paintC = Paint()
        paintC.setAntiAlias(true)
        paintC.setColor(currentColor)
        canvas.drawCircle(radiusPixels, radiusPixels, radiusPixels, paintC)

        // Draw the text
        if (text != null && text.length > 0) {
            val paintT = Paint()
            paintT.setColor(textColor)
            paintT.setAntiAlias(true)
            paintT.setTextSize(radiusPixels * 2)
//            val typeFace = Typeface.createFromAsset(context.getAssets(), "fonts/Roboto-Thin.ttf")
//            paintT.setTypeface(typeFace)
            val textBounds = Rect()
            paintT.getTextBounds(text, 0, text.length, textBounds)
            canvas.drawText(
                text,
                radiusPixels - textBounds.exactCenterX(),
                radiusPixels - textBounds.exactCenterY(),
                paintT
            )
        }
        return output
    }

    fun circleBitmap(resources :Resources,bitmap: Bitmap): RoundedBitmapDrawable {
        val roundedBitmapDrawable: RoundedBitmapDrawable =
            RoundedBitmapDrawableFactory.create(resources, bitmap)
        roundedBitmapDrawable.isCircular = true
        return roundedBitmapDrawable
    }

    fun getFirstLetterFromEachWordInSentence(string: String?): String? {
        if (string == null) {
            return null
        }
        val sb = StringBuilder()
        Arrays.asList(string.split(" ").toTypedArray()).forEach { s -> sb.append(s.get(0)).append(" ") }
        return sb.toString().trim { it <= ' ' }
    }

}