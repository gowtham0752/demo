package com.fiserv.dps.mobile.sdk.bridge.model

class ContactDetailsModel(var mobilenumber : String,var place : String) {
}