package com.fiserv.dps.mobile.sdk.Adapters

import android.content.Context
import android.view.View
import android.view.View.*
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fiserv.dps.mobile.sdk.R
import com.fiserv.dps.mobile.sdk.handlers.inflate
import kotlinx.android.synthetic.main.adapter_contact_details.view.*
import java.util.*

class ContactDetailsAdapter(var context: Context, var model: ArrayList<String>, var click: ContactsClick) : RecyclerView.Adapter<ContactDetailsAdapter.ContactHolder>() {

    class ContactHolder(itemview : View) : RecyclerView.ViewHolder(itemview) {
        fun bindview(data: String, click: ContactsClick) {
            var value = data
            if(value.startsWith("@")){
                value = value.drop(1)
                itemView.img_call.setImageResource(R.drawable.call)
                itemView.image_message.setImageResource(R.drawable.message)
                itemView.cv_call.visibility = VISIBLE
            }else{
                itemView.cv_call.visibility = INVISIBLE
                itemView.img_call.setImageResource(R.drawable.ic_baseline_mail_outline_24)
            }
            itemView.tv_mobile.text = value
            itemView.tv_mobile.setOnClickListener {
                click.getContact(value)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactHolder {
       return ContactHolder(parent.inflate(R.layout.adapter_contact_details))
    }

    override fun onBindViewHolder(holder: ContactHolder, position: Int) {
        holder.bindview(model[position], click)
    }

    override fun getItemCount(): Int {
       return model.size
    }

    interface ContactsClick {
        fun getContact(value:String)
    }
}