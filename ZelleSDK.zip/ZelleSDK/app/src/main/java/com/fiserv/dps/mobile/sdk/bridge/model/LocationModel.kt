package com.fiserv.dps.mobile.sdk.bridge.model

data class LocationModel (
    var latitude:Double? = null,
    var longitude:Double? = null,
    var error: ErrorObject? = null
    )