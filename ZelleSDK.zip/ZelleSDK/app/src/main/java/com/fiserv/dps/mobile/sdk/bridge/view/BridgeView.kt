package com.fiserv.dps.mobile.sdk.bridge.view

import android.app.Activity
import com.fiserv.dps.mobile.sdk.bridge.controller.BridgeFragment
import com.fiserv.dps.mobile.sdk.bridge.model.BridgeConfig

class BridgeView: BridgeFragment {
    constructor() : super()
    constructor( activity: Activity, config: BridgeConfig) : super(activity, config, false)
}