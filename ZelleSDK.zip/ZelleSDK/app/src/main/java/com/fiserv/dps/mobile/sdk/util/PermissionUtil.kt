package com.fiserv.dps.mobile.sdk.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.PERMISSION_DENIED_STRICTLY_CAMERA
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.PERMISSION_DENIED_STRICTLY_CONTACT
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_CAMERA_PERMISSION
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_CAMERA_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_LOCATION_PERMISSION
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_READ_CONTACT_PERMISSION
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_READ_CONTACT_PERMISSION_SETTINGS
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.THRESHOLD_LIMIT_CAMERA
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.THRESHOLD_LIMIT_CONTACT
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.VALID_USER_NAME

object PermissionUtil {

        fun checkPermissionForReadContact(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED )
            } else false
        }

        fun requestPermissionForReadContact(fragment: Fragment) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                fragment.requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS),
                    REQUEST_READ_CONTACT_PERMISSION
                )
            }
        }

    fun checkUserRequestedDontAskAgainContacts(fragment: Fragment, message:String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val rationalFalg_Read_Contact = fragment.shouldShowRequestPermissionRationale(Manifest.permission.READ_CONTACTS)
            if (!rationalFalg_Read_Contact ) {
                val threshold = ThresholdLimitPreference.getLimit(fragment.requireContext(), THRESHOLD_LIMIT_CONTACT)
                if(!threshold.isEmpty()){
                    if(threshold.equals("false",true)){
                        ThresholdLimitPreference.save(THRESHOLD_LIMIT_CONTACT,"true", fragment.requireContext())
                    }else{
                        alertDialogue(fragment , message, positiveButton = "Allow", negativeButton =  "Deny", code = PERMISSION_DENIED_STRICTLY_CONTACT)
                        Log.d("SingleContact", "-------------->Permission Denied Strictly")
                    }
                }else{
                    ThresholdLimitPreference.save(THRESHOLD_LIMIT_CONTACT,"true", fragment.requireContext())
                }

            }
        }
    }

    fun checkPermissionForCamera(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED )
        } else false
    }

    fun requestPermissionForCamera(fragment: Fragment) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            fragment.requestPermissions(arrayOf(Manifest.permission.CAMERA),
                REQUEST_CAMERA_PERMISSION
            )
        }
    }

    fun checkUserRequestedDontAskAgainCamera(fragment: Fragment, message:String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val rationalFalg_Read_Contact = fragment.shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)
            if (!rationalFalg_Read_Contact ) {
                val threshold = ThresholdLimitPreference.getLimit(fragment.requireContext(), THRESHOLD_LIMIT_CAMERA)
                if(!threshold.isEmpty()){
                    if(threshold.equals("false",true)){
                        ThresholdLimitPreference.save(THRESHOLD_LIMIT_CAMERA,"true", fragment.requireContext())
                    }else{
                        alertDialogue(fragment , message, positiveButton = "Allow", negativeButton =  "Deny", code = PERMISSION_DENIED_STRICTLY_CAMERA)
                        Log.d("SingleContact", "-------------->Permission Denied Strictly")
                    }
                }else{
                    ThresholdLimitPreference.save(THRESHOLD_LIMIT_CAMERA,"true", fragment.requireContext())
                }
            }
        }
    }

    fun requestPermissionForLocation(fragment: Fragment) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            fragment.requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_LOCATION_PERMISSION
            )
        }
    }



        fun alertDialogue(fragment: Fragment, message:String , positiveButton:String , negativeButton:String, code:Int){
            val builder = AlertDialog.Builder(fragment.requireContext())
            builder.setMessage(message)
            builder.setPositiveButton(positiveButton) { dialog, which ->

                if(code == PERMISSION_DENIED_STRICTLY_CONTACT) {
                  openSettings(fragment, REQUEST_READ_CONTACT_PERMISSION_SETTINGS)
                }else if (code == VALID_USER_NAME){
                    builder.context
                }else if (code == PERMISSION_DENIED_STRICTLY_CAMERA){
                    openSettings(fragment, REQUEST_CAMERA_PERMISSION_SETTINGS)
                }
            }
            builder.setNegativeButton(negativeButton) { dialog, which -> builder.context }
            builder.create().show()
        }

    fun openSettings(fragment: Fragment , requestCode:Int){
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        val uri = Uri.fromParts("package", fragment.requireContext().packageName, null)
        intent.data = uri
        fragment.startActivityForResult(intent, requestCode)
    }
}