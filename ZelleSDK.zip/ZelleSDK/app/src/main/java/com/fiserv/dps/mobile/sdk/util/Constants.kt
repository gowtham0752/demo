package com.fiserv.dps.mobile.sdk.util

class Constants {

    companion object{
        const  val title : String = "Zelle SDK"
        const  val CONTACT_DENY : String = "Allow Zelle SDK to access your contacts manually"
        const  val CAMERA_DENY : String = "Allow Zelle SDK to access your camera manually"
        const  val CONTACT_DETAILS : String = "contact_details"
        const  val INVALID_CONTACT_NAME : String = "Invalid Contact Name"
        const  val INVALID_CONTACT_DETAIL : String = "Invalid Contact Detail"
        const  val NO_DATA_FOUND : String = "No Data Found"
        const  val INVALID_QR_CODE : String = "Invalid QR Code"
        const  val THRESHOLD_LIMIT_CONTACT : String = "threshold_limit_contact"
        const  val THRESHOLD_LIMIT_CAMERA : String = "threshold_limit_camera"
        const  val CACHING_TIME : String = "caching_time"
        const  val CACHED_CONTACT : String = "cached_contact"
        const val REQUEST_READ_CONTACT_PERMISSION = 100
        const val REQUEST_READ_CONTACT_PERMISSION_SETTINGS = 101
        const val REQUEST_READ_CONTACT_DETAILS_PERMISSION = 102
        const val REQUEST_CAMERA_PERMISSION_SETTINGS = 201
        const val REQUEST_CAMERA_PERMISSION = 200
        const val REQUEST_LOCATION_PERMISSION = 300
        const val PERMISSION_DENIED_STRICTLY_CONTACT = 1
        const val VALID_USER_NAME = 2
        const val ENABLE_GPS = 105
        const val PERMISSION_DENIED_STRICTLY_CAMERA = 3

    }



}