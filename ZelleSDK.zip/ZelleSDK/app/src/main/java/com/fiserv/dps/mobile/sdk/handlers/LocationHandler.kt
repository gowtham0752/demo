package com.fiserv.dps.mobile.sdk.handlers

import android.Manifest
import android.app.Activity
import android.content.Context.LOCATION_SERVICE
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.location.LocationManager
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.fragment.app.Fragment
import com.fiserv.dps.mobile.sdk.bridge.model.LocationModel
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.ENABLE_GPS
import com.fiserv.dps.mobile.sdk.util.JsonConverson.toJSON
import com.fiserv.dps.mobile.sdk.util.PermissionUtil.requestPermissionForLocation
import com.google.gson.Gson


interface LocationHandler {
    @JavascriptInterface fun getLocation()
}

class LocationHandlerImpl(private val activity: Fragment, private val evaluateJS: (String)->Unit): LocationHandler, LocationListener {
    var locationManager: LocationManager? = null
    @JavascriptInterface override fun getLocation() {
        locationManager()
    }

    fun locationManager(){
        locationManager = activity.requireContext().getSystemService(LOCATION_SERVICE) as LocationManager
        if (ActivityCompat.checkSelfPermission(activity.requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity.requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionForLocation(activity)
            return
        }
       val gpsStatus = locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)
        if (gpsStatus)
        locationManager!!.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0f, this)
        else{
            val intent1 = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            activity.startActivityForResult(intent1, ENABLE_GPS)
        }

    }



    override fun onLocationChanged(location: Location) {
        val getlocation = LocationModel()
        getlocation.latitude = location.latitude
        getlocation.longitude = location.longitude
        locationManager!!.removeUpdates(this)
        Log.d("Location","--------------------->${toJSON(getlocation)}")
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackLocation({location: '${toJSON(getlocation)}'})")
        }, 1000)
    }

    fun turnOnGPS(){

    }
}