package com.fiserv.dps.mobile.sdk.util

import org.json.JSONException
import org.json.JSONObject

object JsonConverson {

    @kotlin.jvm.Throws(JSONException::class, IllegalAccessException::class)
    fun toJSON(`object`: Any): String {
        val str = ""
        val c: Class<*> = `object`.javaClass
        val jsonObject = JSONObject()
        for (field in c.declaredFields) {
            field.isAccessible = true
            val name = field.name
            val value = java.lang.String.valueOf(field[`object`])
            if (!value.equals("null", true))
            jsonObject.put(name, value)
        }
        println(jsonObject.toString())
        return jsonObject.toString()
    }
}