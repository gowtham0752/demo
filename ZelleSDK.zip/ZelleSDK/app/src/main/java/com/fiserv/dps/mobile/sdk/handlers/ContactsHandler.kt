package com.fiserv.dps.mobile.sdk.handlers

import android.app.Dialog
import android.content.Context
import android.content.SharedPreferences
import android.database.Cursor
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.util.Log
import android.webkit.JavascriptInterface
import com.fiserv.dps.mobile.sdk.bridge.model.Contact
import android.content.Intent
import androidx.fragment.app.Fragment
import com.fiserv.dps.mobile.sdk.util.Constants
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.CACHING_TIME
import com.fiserv.dps.mobile.sdk.util.Constants.Companion.REQUEST_READ_CONTACT_PERMISSION
import com.fiserv.dps.mobile.sdk.util.PermissionUtil
import com.fiserv.dps.mobile.sdk.util.ThresholdLimitPreference
import com.fiserv.dps.mobile.sdk.util.TimePicker.getCurrentTime
import com.fiserv.dps.mobile.sdk.util.TimePicker.getExtraHourwithTimeGiven
import com.fiserv.dps.mobile.sdk.util.TimePicker.timeDifferenceInHour
import org.json.JSONArray
import org.json.JSONObject


interface ContactsHandler {
    @JavascriptInterface fun getContacts()
    @JavascriptInterface fun getOneContact()
}

class ContactsHandlerImpl(private val activity: Fragment, private val evaluateJS: (String)->Unit): ContactsHandler {

    var cursor: Cursor? = null
    private val RequestPermissionCode = 1
    var name: String? = null
    var phonenumber: String? = null
    var sharedPreferences : SharedPreferences? = null

    @JavascriptInterface override fun getContacts() {

        if(PermissionUtil.checkPermissionForReadContact(activity.requireContext())){
            var ss = ThresholdLimitPreference.getLimit(activity.requireContext() ,
                Constants.CACHED_CONTACT
            )
            if (!ss.isNullOrEmpty()){
                var json = JSONArray(ss)
                val js = "var cachedContacts = ${json};"
                Handler(Looper.getMainLooper()).postDelayed({
                    evaluateJS(js)
                }, 1000)

                var jsonObject = JSONObject()
                jsonObject.put("cached", true)
                Handler(Looper.getMainLooper()).postDelayed({
                    evaluateJS("callbackContacts({contact: '${jsonObject}'})")
                }, 1000)

            }else {
                val getContacts =
                    ContactsThreadHandler(fragment = activity, evaluateJS = evaluateJS)
                Thread(getContacts).start()
            }
        }else{
            PermissionUtil.requestPermissionForReadContact(fragment = activity)
        }

//        val cache = ThresholdLimitPreference.getLimit(activity.requireContext(), CACHING_TIME)
//        if(!cache.isEmpty()){
//            val getextraTime = getExtraHourwithTimeGiven(24, cache)
//            val time = timeDifferenceInHour(getextraTime, getCurrentTime())
//            if(time.get(0)!! <= 0 && time.get(1)!! <= 0){
//                ThresholdLimitPreference.save(CACHING_TIME, getCurrentTime(), activity.requireContext())
//                sendContactsCallback("true")
//                Log.d("Remaining Time","-----------------Cached")
//            }else{
//                Log.d("Remaining Time","-----------------${time.get(0)}")
//                sendContactsCallback("true")
//            }
//        }else{
//            ThresholdLimitPreference.save(CACHING_TIME, getCurrentTime(), activity.requireContext())
//            sendContactsCallback("true")
//            Log.d("Remaining Time","-----------------Empty")
//        }



    }

    fun sendContactsCallback(cached:String){
        Handler(Looper.getMainLooper()).postDelayed({
            evaluateJS("callbackContacts({contacts: '${cached}'})")
        }, 1000)
    }
    @JavascriptInterface override fun getOneContact() {
        sharedPreferences = activity.requireContext().getSharedPreferences("zelle", Context.MODE_PRIVATE)
        var allowed = sharedPreferences!!.getBoolean("allowed", false)

        if(PermissionUtil.checkPermissionForReadContact(activity.requireContext())){
            getSingleContact()
        }else{
            PermissionUtil.requestPermissionForReadContact(fragment = activity)
        }
    }

    private fun getContact(key : String) {

        var contact : Contact? = null

        cursor = activity.requireContext().contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            null,
            null,
            null
        )
        while (cursor!!.moveToNext()) {
            name =
                cursor!!.getString(cursor!!.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME ))
            phonenumber =
                cursor!!.getString(cursor!!.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))

            if (name.toString().toLowerCase().trim().contains(key.toLowerCase().trim()) || phonenumber.toString().contains(key)) {
                contact = Contact()
                var phoneNumbers = ArrayList<String>()
                phoneNumbers.add(phonenumber!!)
                contact.name = name
                contact.phone = phoneNumbers
            }
        }
        cursor!!.close()

        if(contact == null) {
            Handler(Looper.getMainLooper()).postDelayed({
                evaluateJS("callbackOneContact({contact: '${"Contact Not Found"}'})")
            }, 1000)
        } else {

            Log.d("Contact Name", contact!!.name.toString())
            Handler(Looper.getMainLooper()).postDelayed({
                evaluateJS("callbackOneContact({contact: '${contact!!.name + "," + contact!!.phone}'})")
            }, 1000)
        }

    }

    fun getSingleContact(){
        val i = Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI)
        //i.type = type
        activity.startActivityForResult(i , REQUEST_READ_CONTACT_PERMISSION)

    }


}