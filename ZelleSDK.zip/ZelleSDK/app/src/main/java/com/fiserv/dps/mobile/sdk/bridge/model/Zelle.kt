package com.fiserv.dps.mobile.sdk.bridge.model

class Zelle(
    private val institutionId: String,
    private val ssoKey: String,
    //private val parameters: Map<String, String> = mapOf()
    private val complete_url: String,
    private val parameters: Map<String, String>? = null
): BridgeConfig {
    override var url = ""
    override var preCacheContacts = false

    init {
        //prepare the url using passed parameters
        url = "https://dhayaaperumal.github.io/demo/index.html"
        //url = "https://www.instagram.com/accounts/login/"
        url = complete_url
       // url += "?institutionId=$institutionId&key=$ssoKey"
        if(parameters != null)
        url += parameters.map { it.key + "=" + it.value }.joinToString("&", "&")
    }
}