package com.fiserv.dps.mobile.sdk.util

import android.annotation.SuppressLint
import android.content.*
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import android.util.Base64
import android.util.Log
import com.fiserv.dps.mobile.sdk.util.Validator.validateEmail
import com.fiserv.dps.mobile.sdk.util.Validator.validateMobileNumber
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import com.fiserv.dps.mobile.sdk.bridge.model.Contacts
import java.lang.Exception


object ContactUtil {

        fun getContactNumber(context: Context,  contactID:String , validation:Boolean): ArrayList<String>? {
            val contactNumber = ArrayList<String>()
            var duplicateNumber = HashSet<String>()
            val cursorPhone: Cursor = context.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", arrayOf(contactID),
                null
            )!!
            while (cursorPhone.moveToNext()) {
                val phone = cursorPhone.getString(cursorPhone.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                if(validation) {
                    if (validateMobileNumber(phone)) {
                        var number = phone.filter { it.isDigit() }
                        contactNumber.add(number)
                    }
                }else{
                    contactNumber.add("@"+phone)
                }
            }
            cursorPhone.close()
            duplicateNumber.addAll(contactNumber)
            contactNumber.clear()
            contactNumber.addAll(duplicateNumber)
            return contactNumber
        }

        fun getNameEmailDetails(context: Context,  contactID:String, validation: Boolean): ArrayList<String>? {
            val emailId = ArrayList<String>()
            var duplicateMail = HashSet<String>()
            val cursorPhone: Cursor = context.getContentResolver().query(
                ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
                ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?", arrayOf(contactID),
                null
            )!!
            while (cursorPhone.moveToNext()) {
                val email = cursorPhone.getString(cursorPhone.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA))
                if(validation) {
                    if (validateEmail(email)) {

                        emailId.add(email.toLowerCase())
                    }
                }else{
                    emailId.add(email.toLowerCase())
                }
            }
            cursorPhone.close()
            duplicateMail.addAll(emailId)
            emailId.clear()
            emailId.addAll(duplicateMail)
            return emailId
        }

         fun getContactPhoto(context: Context,  contactID:String) :Bitmap?{
            var photo: Bitmap? = null
            try {
                val inputStream: InputStream? = ContactsContract.Contacts.openContactPhotoInputStream(
                    context.contentResolver,
                    ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactID.toLong())
                )
                if (inputStream != null) {
                    photo = BitmapFactory.decodeStream(inputStream)
                    return photo
                    inputStream.close()
                   // fragment_holder.setImageBitmap(photo)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }

         fun getContactName(context: Context, uriContact:Uri ):String {
            var contactName: String? = null

            // querying contact data store
            val cursor = context.contentResolver.query(uriContact, null, null, null, null)
            if (cursor!!.moveToFirst()) {

                // DISPLAY_NAME = The display name for the contact.
                // HAS_PHONE_NUMBER =   An indicator of whether this contact has at least one phone number.
                contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))
            }
            cursor.close()
            Log.d(ContentValues.TAG, "------------------>Contact Name: $contactName")
            return contactName!!
        }

        fun BitMapToString(bitmap: Bitmap): String? {
            val bios = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bios)
          //  val b = baos.toByteArray()
            var quality = 90
            while (bios.toByteArray().size / 1024  > 1024){
                bios.reset()
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, bios)
                quality -= 5
            }
            Log.d(ContentValues.TAG, "------------------>Size: ${(bios.toByteArray().size)}")

            return Base64.encodeToString(bios.toByteArray(), Base64.DEFAULT)
        }


    @SuppressLint("Recycle")
    fun getContactDataFrom(contentResolver: ContentResolver, contactUri: Uri): Contacts? {
        var name = ""
        var phone = ""
        var EmailID = ""
        try {
            val cursor= contentResolver.query(contactUri, null, null, null, null)?: return null
            if (!cursor.moveToFirst()) {
                return null
            }
            Log.d("Single Data","---------------------->Printed")
            if(cursor.moveToFirst()){
                val id: String = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID))
                name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))
                phone = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                EmailID= cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA))
                Log.d("Name","---------------------->$name ,  $phone ,  $EmailID")

                if(validateMobileNumber(phone)){
                    EmailID = ""
                }else if(validateEmail(EmailID)){
                    phone = ""
                }else{
                    EmailID = ""
                    phone = ""
                }

            }
            return Contacts(name, phone, EmailID)
        } catch (e: Exception) {
            Log.e("Contacts", "Could not get contact info.", e)
            return null
        }
    }

    @SuppressLint("Recycle")
    private fun getPhoneNumber(contentResolver: ContentResolver, id: String?): String {
        var phoneNumber = ""

        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            ContactsContract.Contacts._ID + " = ?",
            arrayOf(id),
            null
        ) ?: return phoneNumber

        if (cursor.moveToFirst()) {
            phoneNumber = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DATA))
            if(!validateMobileNumber(phoneNumber)){
                phoneNumber = ""
            }
        }

        cursor.close()
        return phoneNumber
    }



}