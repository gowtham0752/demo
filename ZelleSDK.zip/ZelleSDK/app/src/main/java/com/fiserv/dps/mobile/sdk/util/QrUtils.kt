package com.fiserv.dps.mobile.sdk.util

import com.fiserv.dps.mobile.sdk.bridge.model.Contacts
import com.fiserv.dps.mobile.sdk.util.Validator.validateContact
import com.google.gson.Gson
import java.lang.Exception

object QrUtils {

    fun checkQrCode(data:String):Boolean{
        try {
            val contacts = Gson().fromJson(data , Contacts::class.java)
            if (validateContact(contacts)){
                return true
            }
        }catch (e :Exception){
            return false
        }
        return false
    }
}