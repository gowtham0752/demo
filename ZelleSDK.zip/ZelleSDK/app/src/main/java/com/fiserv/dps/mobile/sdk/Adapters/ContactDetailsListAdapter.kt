package com.fiserv.dps.mobile.sdk.Adapters

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import com.fiserv.dps.mobile.sdk.R
import kotlinx.android.synthetic.main.adapter_contact_details.view.*
import java.util.ArrayList

class ContactDetailsListAdapter(val context: Activity, val model: ArrayList<String>, var click: ContactsClick)
    : ArrayAdapter<String>(context, R.layout.adapter_contact_details, model) {
  
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater  
        val rowView = inflater.inflate(R.layout.adapter_contact_details, null, true)

        var value = model[position]
        if(value.startsWith("@")){
            value = value.drop(1)
            rowView.img_call.setImageResource(R.drawable.call)
            rowView.image_message.setImageResource(R.drawable.message)
            rowView.cv_call.visibility = View.VISIBLE
        }else{
            rowView.cv_call.visibility = View.INVISIBLE
            rowView.img_call.setImageResource(R.drawable.ic_baseline_mail_outline_24)
        }
        rowView.tv_mobile.text = value
        rowView.tv_mobile.setOnClickListener {
            click.getContact(value)
        }
  
        return rowView  
    }

    interface ContactsClick {
        fun getContact(value:String)
    }
}  