package com.fiserv.dps.mobile.sdk.util

import android.content.Context

class AppComUtils {
    companion object{
        private val PREFS_NAME = "Zelle"

        fun setPreferenceString(context: Context, key:String, value: String){
            if (context == null) {
                return
            }
            val settings = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val editor = settings.edit()
            editor.putString(key, value)
            editor.apply()
            editor.commit()
        }

        fun getPreferenceString(context: Context , key: String):String{
            if (context == null) {
                return ""
            }
            val pref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return pref.getString(key, "")!!
        }
    }

}