package com.fiserv.dps.mobile.sdk.bridge.model

import android.graphics.Bitmap

//data class Contact(var name: String?, var number : String?) {
//
//    init {
//        this.name = name
//        this.number = number
//    }
//}

class Contact() {
    var name: String? = null
    var phone = ArrayList<String>()
    var email = ArrayList<String>()
    var photoBase64:String? = null
    var photoBitmap:Bitmap? = null
    var error:ErrorObject? = null

}

class Contacts(name: String?, phoneNumber: String?, email: String?) {
    var id : Int? = null
    var name: String? = null
    var phone:String? = null
    var email:String? = null
    var photoBase64:String? = null
    var error:ErrorObject? = null
    init {
        this.name = name
        this.email = email
        this.phone = phoneNumber
    }

}