package com.fiserv.dps.mobile.sdk.util

import com.fiserv.dps.mobile.sdk.bridge.model.Contacts


object Validator {

    fun validateMobileNumber(number1 : String) : Boolean {
      var pattern = "[0-9\\.\\-\\+\\,\\(\\)\\ ]+";
        if(!number1.matches(pattern.toRegex())){
            return false
        }
    var  number = number1.filter { it.isDigit() }
    if (number.length == 11 && number.startsWith("1")) {
        number=number.drop(1)
        var pattern = "^(?!0|1|000|800|844|855|866|877|888)\\d{10}$"
      //  Log.d("Validator", "MobileNumber----------------- 11>${number.matches(pattern.toRegex())}")
        return (number.matches(pattern.toRegex()) )
    } else if (number.length == 10) {
        var pattern = "^(?!0|1|000|800|844|855|866|877|888)\\d{10}$"
      //  Log.d("Validator", "MobileNumber----------------- 10>${number.matches(pattern.toRegex())}")
        return (number.matches(pattern.toRegex()))
    }
       // Log.d("Validator", "MobileNumber----------------->${"false"})}")
    return false
}

    fun validateName(name : String) : Boolean {
       // Log.d("Validator", "Name----------------->${name}")
      //  Log.d("Validator", "Name----------------->${(!name.isEmpty() ||  name != null) && (name.length >= 2 && name.length <= 30) })}")
    return ((!name.isEmpty() ||  name != null) && (name.length >= 2 && name.length <= 30)  )
    }

    fun    validateEmail(email : String) : Boolean {

   //  var emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
      //  Log.d("Validator", "Mail_Id----------------->${email}")
       // var emailPattern =   "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,4})$"
       var emailPattern = "[_A-Za-z0-9\$]+([\\.\\-][_A-Za-z0-9\$]+)*@[A-Za-z0-9]+([\\.\\-][A-Za-z0-9]+)*\\.[A-Za-z]{2,4}\$"
     //   Log.d("Validator", "Mail_Id----------------->${email.matches(emailPattern.toRegex())}")
    return (email.matches(emailPattern.toRegex()))
    }

    fun validateContact(constants: Contacts):Boolean{
        if(validateName(constants.name!!)){
            if(constants.phone != null){
               if(validateMobileNumber(constants.phone!!))
                return true
            }else if (constants.email != null){
                if(validateEmail(constants.email!!))
                return true
            }
        }
        return false
    }


}