package com.fiserv.dps.mobile.sdk.bridge.model

class ErrorObject() {

    var errorName : String? = null
}