package com.fiserv.dps.mobile.sdk.bridge.model

data class QrModel(
    var user_action:String = "accepted",
    var user_value:String? = null
)
