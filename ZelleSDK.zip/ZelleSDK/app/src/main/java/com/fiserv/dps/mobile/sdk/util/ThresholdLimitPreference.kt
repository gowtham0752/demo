package com.fiserv.dps.mobile.sdk.util

import android.content.Context
import androidx.annotation.Nullable
import org.json.JSONArray

class ThresholdLimitPreference {

    companion object{

        fun save(@Nullable key : String, @Nullable value : String, context: Context?) {
            AppComUtils.setPreferenceString(context!!, key, value)
        }

        @Nullable
        fun getLimit(context: Context?,key: String): String {
            return AppComUtils.getPreferenceString(context!!, key)

        }

    }
}