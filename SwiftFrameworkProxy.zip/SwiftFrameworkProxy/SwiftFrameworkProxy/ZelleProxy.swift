//
//  ZelleProxy.swift
//  SwiftFrameworkProxy
//
//  Created by Rac on 18/07/22.
//

import Foundation
import UIKit
import ZelleSDK

@objc(ZelleProxy)
public class ZelleProxy : NSObject {
    
    @objc
    public func launchZelle(viewController: UIViewController, applicationName: String, baseUrl: String, institutionId: String, ssoKey: String, product: String) {
        
        let zelle = Zelle(
            applicationName: applicationName,
            baseUrl: baseUrl,
            institutionId: institutionId,
            product: product,
            ssoKey: ssoKey,
            parameters: [
                "key1" : "value1",
                "key2" : "value2"
            ]
        )

        let bridge: Bridge = {
            Bridge(
                config: zelle,
                viewController: viewController.self
            )
        }()
        
        let zelleFrame = CGRect(x:0, y:0, width:viewController.view.frame.width, height:viewController.view.frame.height) //desired location
        let zelleView = bridge.view(frame: zelleFrame)
        viewController.view.addSubview(zelleView)
    }

}
