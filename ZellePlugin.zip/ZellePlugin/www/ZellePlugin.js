
var exec = require('cordova/exec');

 function plugin() {

    }

    plugin.prototype.zelle_activity = function(zelleObject) {
        exec(function(res){}, function(err){}, "ZellePlugin", "zelle_activity", [zelleObject]);
    }

    module.exports = new plugin();
