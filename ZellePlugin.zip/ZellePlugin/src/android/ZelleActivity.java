package com.fiserv.dps.mobile.zelleplugin;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge;
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle;
import com.fiserv.dps.mobile.sdk.bridge.view.BridgeView;

import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.CordovaInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import com.fiserv.dps.mobile.cordovaFI.R;
import com.google.gson.Gson;


public class ZelleActivity extends AppCompatActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String package_name = getApplication().getPackageName();
        setContentView(getApplication().getResources().getIdentifier("activity_zelle", "layout", package_name));
        Intent intent = getIntent();
        try {
            if (intent != null){
            JSONObject jsonObject = new JSONObject(intent.getStringExtra("ZelleObject"));
            HashMap<String, String> param = new Gson().fromJson(jsonObject.getString("parameters"), HashMap.class);
            Zelle zelle = new Zelle(
                    jsonObject.getString("applicationName"),
                    jsonObject.getString("baseURL"),
                    jsonObject.getString("institutionId"),
                    jsonObject.getString("product"),
                    jsonObject.getString("ssoKey"),
                    param
            );
            Bridge bridge = new Bridge(ZelleActivity.this, zelle);
            zelle.setPreCacheContacts(true);
            BridgeView view1 = bridge.view();
            getSupportFragmentManager().beginTransaction().replace(R.id.textView, view1).commit();
          }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        
        //getSupportFragmentManager().beginTransaction().replace(R.id.textView,view1).commit()
    }
}
